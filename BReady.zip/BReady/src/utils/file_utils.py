"""
File Utility Functions
Handles file uploads and text extraction
"""
import os
import tempfile
from typing import Optional


def extract_text_from_file(file_path: str) -> str:
    """Extract text from PDF, DOCX, or TXT file"""
    file_ext = file_path.lower().split('.')[-1]
    
    if file_ext == 'pdf':
        import pdfplumber
        with pdfplumber.open(file_path) as pdf:
            return "\n".join([page.extract_text() or "" for page in pdf.pages])
    
    elif file_ext == 'docx':
        from docx import Document
        doc = Document(file_path)
        return "\n".join([para.text for para in doc.paragraphs])
    
    elif file_ext == 'txt':
        with open(file_path, 'r', encoding='utf-8') as f:
            return f.read()
    
    else:
        raise ValueError(f"Unsupported file format: {file_ext}")


def save_uploaded_file(uploaded_file) -> Optional[str]:
    """Save uploaded file temporarily and return path"""
    try:
        file_ext = uploaded_file.name.split('.')[-1]
        with tempfile.NamedTemporaryFile(delete=False, suffix=f".{file_ext}") as tmp_file:
            tmp_file.write(uploaded_file.getvalue())
            return tmp_file.name
    except Exception as e:
        raise Exception(f"Error saving file: {str(e)}")


def cleanup_file(file_path: str):
    """Delete temporary file"""
    try:
        if os.path.exists(file_path):
            os.unlink(file_path)
    except Exception:
        pass  # Ignore cleanup errors

