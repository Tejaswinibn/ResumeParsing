"""
UI Helper Functions for Streamlit App
Simplifies and organizes UI components
"""
import streamlit as st
from typing import Dict, List


def render_sidebar():
    """Render sidebar with configuration and info"""
    st.header("⚙️ Configuration")
    
    st.subheader("OpenAI API (Optional)")
    st.markdown("For enhanced report generation, add your OpenAI API key in Streamlit Secrets or `.env` file")
    
    import config
    if not config.OPENAI_API_KEY:
        st.warning("⚠️ OpenAI API key not found. Using template reports.")
    else:
        st.success("✅ OpenAI API configured")
    
    st.markdown("---")
    st.subheader("📊 About")
    st.markdown("""
    This tool helps you:
    - Parse resumes and job descriptions
    - Analyze candidate fit using semantic similarity
    - Rank candidates intelligently
    - Generate explainable evaluation reports
    """)


def display_candidate_summary(candidate: Dict, index: int):
    """Display summary of a parsed candidate"""
    with st.expander(f"Candidate {index+1}: {candidate.get('name', 'Unknown')}"):
        col1, col2 = st.columns(2)
        with col1:
            st.write("**Contact:**")
            st.write(f"Email: {candidate.get('email', 'N/A')}")
            st.write(f"Phone: {candidate.get('phone', 'N/A')}")
            st.write(f"**Skills:** {', '.join(candidate.get('skills', [])[:10])}")
        with col2:
            st.write(f"**Experience:** {len(candidate.get('experience', []))} positions")
            st.write(f"**Projects:** {len(candidate.get('projects', []))} projects")
            st.write(f"**Education:** {len(candidate.get('education', []))} entries")


def display_ranking_summary(ranked_candidates: List[Dict]):
    """Display ranking summary table"""
    import pandas as pd
    
    summary_data = []
    for i, item in enumerate(ranked_candidates):
        candidate = item['candidate']
        breakdown = item['score_breakdown']
        summary_data.append({
            'Rank': i + 1,
            'Name': candidate.get('name', 'Unknown'),
            'Overall Score': f"{item['score']:.1%}",
            'Skills': f"{breakdown.get('skill_similarity', 0):.1%}",
            'Experience': f"{breakdown.get('experience_relevance', 0):.1%}",
            'Projects': f"{breakdown.get('project_similarity', 0):.1%}"
        })
    
    df = pd.DataFrame(summary_data)
    st.dataframe(df, use_container_width=True, hide_index=True)


def display_candidate_details(item: Dict, rank: int):
    """Display detailed candidate ranking information"""
    candidate = item['candidate']
    score = item['score']
    breakdown = item['score_breakdown']
    human_insights = item.get('human_insights', [])
    
    with st.expander(f"Rank {rank}: {candidate.get('name', 'Unknown')} - Score: {score:.1%}"):
        # Human-like insights (if available)
        if human_insights:
            st.info("🧠 **Human-Like Analysis Insights:**\n" + "\n".join([f"• {insight}" for insight in human_insights]))
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.write("**Candidate Information**")
            st.write(f"Email: {candidate.get('email', 'N/A')}")
            st.write(f"Phone: {candidate.get('phone', 'N/A')}")
            st.write(f"**Skills:** {', '.join(candidate.get('skills', [])[:15])}")
        
        with col2:
            st.write("**Score Breakdown**")
            st.metric("Overall Score", f"{score:.1%}")
            
            # Check if human-like scores exist
            if 'career_trajectory' in breakdown:
                st.write("**🧠 Human-Like Factors:**")
                st.metric("Career Trajectory", f"{breakdown.get('career_trajectory', 0):.1%}")
                st.metric("Problem Solving", f"{breakdown.get('problem_solving', 0):.1%}")
                st.metric("Impact & Achievements", f"{breakdown.get('impact_achievements', 0):.1%}")
                st.metric("Transferable Potential", f"{breakdown.get('transferable_potential', 0):.1%}")
                st.metric("Learning Potential", f"{breakdown.get('learning_potential', 0):.1%}")
            else:
                st.write("**📊 Traditional Factors:**")
                st.metric("Skill Similarity", f"{breakdown.get('skill_similarity', 0):.1%}")
                st.metric("Experience Relevance", f"{breakdown.get('experience_relevance', 0):.1%}")
                st.metric("Project Similarity", f"{breakdown.get('project_similarity', 0):.1%}")
        
        # Skill analysis
        skill_analysis = breakdown.get('skill_analysis', {})
        if skill_analysis:
            col3, col4 = st.columns(2)
            with col3:
                st.write("**Matched Skills:**")
                matched = [m.get('candidate_skill') for m in skill_analysis.get('matched_skills', [])]
                st.write(', '.join(matched[:10]) if matched else 'None')
            with col4:
                st.write("**Missing Skills:**")
                missing = skill_analysis.get('missing_skills', [])
                st.write(', '.join(missing[:10]) if missing else 'None')

