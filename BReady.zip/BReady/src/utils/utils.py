"""
Utility functions for the AI Recruitment Assistant
"""
import logging
import os
from typing import List, Dict, Optional, Tuple
from datetime import datetime


def setup_logging(log_level: str = "INFO", log_file: Optional[str] = None):
    """
    Setup logging configuration
    
    Args:
        log_level: Logging level (DEBUG, INFO, WARNING, ERROR)
        log_file: Optional file path for logging
    """
    logging.basicConfig(
        level=getattr(logging, log_level.upper()),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(),
            *([logging.FileHandler(log_file)] if log_file else [])
        ]
    )


def validate_file(file_path: str, allowed_extensions: List[str], max_size_mb: int = 10) -> Tuple[bool, Optional[str]]:
    """
    Validate uploaded file
    
    Args:
        file_path: Path to file
        allowed_extensions: List of allowed file extensions
        max_size_mb: Maximum file size in MB
        
    Returns:
        Tuple of (is_valid, error_message)
    """
    if not os.path.exists(file_path):
        return False, "File does not exist"
    
    # Check extension
    file_ext = os.path.splitext(file_path)[1].lower()
    if file_ext not in allowed_extensions:
        return False, f"File extension {file_ext} not allowed. Allowed: {allowed_extensions}"
    
    # Check size
    file_size_mb = os.path.getsize(file_path) / (1024 * 1024)
    if file_size_mb > max_size_mb:
        return False, f"File size {file_size_mb:.2f}MB exceeds maximum {max_size_mb}MB"
    
    return True, None


def format_score(score: float) -> str:
    """Format score as percentage"""
    return f"{score:.1%}"


def format_duration(duration_str: str) -> Optional[float]:
    """
    Parse duration string to years (approximate)
    
    Examples:
        "2020 - 2022" -> 2.0
        "2 years" -> 2.0
        "18 months" -> 1.5
    """
    if not duration_str:
        return None
    
    duration_lower = duration_str.lower()
    
    # Try to extract years from date range
    import re
    year_pattern = r'(\d{4})'
    years = re.findall(year_pattern, duration_str)
    if len(years) >= 2:
        try:
            start_year = int(years[0])
            end_year = int(years[1])
            return float(end_year - start_year)
        except ValueError:
            pass
    
    # Try to extract number with "year" or "month"
    number_pattern = r'(\d+(?:\.\d+)?)\s*(?:year|yr|month|mo)'
    match = re.search(number_pattern, duration_lower)
    if match:
        number = float(match.group(1))
        if 'month' in duration_lower or 'mo' in duration_lower:
            return number / 12.0
        return number
    
    return None


def extract_key_phrases(text: str, max_phrases: int = 10) -> List[str]:
    """Extract key phrases from text (simple implementation)"""
    import re
    from collections import Counter
    
    # Remove special characters and split
    words = re.findall(r'\b[a-z]{3,}\b', text.lower())
    
    # Count word frequencies
    word_freq = Counter(words)
    
    # Return most common words
    return [word for word, _ in word_freq.most_common(max_phrases)]


def create_timestamp() -> str:
    """Create timestamp string"""
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def safe_get(data: Dict, *keys, default=None):
    """Safely get nested dictionary values"""
    result = data
    for key in keys:
        if isinstance(result, dict):
            result = result.get(key, default)
        else:
            return default
    return result

