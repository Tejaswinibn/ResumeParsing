"""
Resume Parser Module - Production Version
Extracts structured data from resumes using NLP techniques
"""
import re
import spacy
from typing import Dict, List, Optional
from datetime import datetime
import pdfplumber
from docx import Document
import nltk
from nltk.tokenize import sent_tokenize, word_tokenize

# Download required NLTK data
try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    nltk.download('punkt', quiet=True)

try:
    nltk.data.find('tokenizers/punkt_tab')
except LookupError:
    nltk.download('punkt_tab', quiet=True)


class ResumeParser:
    """Parse resumes and extract structured information"""
    
    def __init__(self):
        try:
            self.nlp = spacy.load("en_core_web_sm")
        except OSError:
            print("spaCy model 'en_core_web_sm' not found. Using basic parsing.")
            self.nlp = None
    
    def parse_file(self, file_path: str) -> Dict:
        """Parse a resume file (PDF, DOCX, or TXT)"""
        file_ext = file_path.lower().split('.')[-1]
        
        if file_ext == 'pdf':
            text = self._extract_from_pdf(file_path)
        elif file_ext == 'docx':
            text = self._extract_from_docx(file_path)
        elif file_ext == 'txt':
            with open(file_path, 'r', encoding='utf-8') as f:
                text = f.read()
        else:
            raise ValueError(f"Unsupported file format: {file_ext}")
        
        return self.parse_text(text)
    
    def _extract_from_pdf(self, file_path: str) -> str:
        """Extract text from PDF file"""
        text = ""
        try:
            with pdfplumber.open(file_path) as pdf:
                for page in pdf.pages:
                    text += page.extract_text() or ""
        except Exception as e:
            print(f"Error extracting PDF: {e}")
        return text
    
    def _extract_from_docx(self, file_path: str) -> str:
        """Extract text from DOCX file"""
        doc = Document(file_path)
        return "\n".join([para.text for para in doc.paragraphs])
    
    def parse_text(self, text: str) -> Dict:
        """Parse resume text and extract structured data"""
        if not self.nlp:
            return self._basic_parse(text)
        
        doc = self.nlp(text)
        
        # Extract information
        parsed_data = {
            "name": self._extract_name(doc, text),
            "email": self._extract_email(text),
            "phone": self._extract_phone(text),
            "skills": self._extract_skills(doc, text),
            "experience": self._extract_experience(doc, text),
            "education": self._extract_education(doc, text),
            "projects": self._extract_projects(doc, text),
            "certifications": self._extract_certifications(text),
            "soft_skills": self._extract_soft_skills(doc, text),
            "raw_text": text
        }
        
        return parsed_data
    
    def _basic_parse(self, text: str) -> Dict:
        """Basic parsing without spaCy"""
        return {
            "name": self._extract_name_basic(text),
            "email": self._extract_email(text),
            "phone": self._extract_phone(text),
            "skills": self._extract_skills_basic(text),
            "experience": [],
            "education": [],
            "projects": [],
            "certifications": [],
            "soft_skills": [],
            "raw_text": text
        }
    
    def _extract_name(self, doc, text: str) -> Optional[str]:
        """Extract candidate name (first line or first proper noun)"""
        lines = text.split('\n')[:5]
        for line in lines:
            line = line.strip()
            if len(line) > 0 and len(line.split()) <= 4:
                if not any(keyword in line.lower() for keyword in ['email', 'phone', 'linkedin', 'github', 'resume', 'cv']):
                    return line
        return None
    
    def _extract_name_basic(self, text: str) -> Optional[str]:
        """Basic name extraction"""
        lines = text.split('\n')[:3]
        for line in lines:
            line = line.strip()
            if len(line) > 0 and len(line.split()) <= 4:
                if not any(keyword in line.lower() for keyword in ['email', 'phone', 'linkedin']):
                    return line
        return None
    
    def _extract_email(self, text: str) -> Optional[str]:
        """Extract email address"""
        email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        match = re.search(email_pattern, text)
        return match.group(0) if match else None
    
    def _extract_phone(self, text: str) -> Optional[str]:
        """Extract phone number"""
        phone_patterns = [
            r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',
            r'\(\d{3}\)\s?\d{3}[-.]?\d{4}',
            r'\+\d{1,3}[-.\s]?\d{1,4}[-.\s]?\d{1,4}[-.\s]?\d{1,9}'
        ]
        for pattern in phone_patterns:
            match = re.search(pattern, text)
            if match:
                return match.group(0)
        return None
    
    def _extract_skills(self, doc, text: str) -> List[str]:
        """Extract technical skills"""
        # Common technical skills keywords
        skill_keywords = [
            'python', 'java', 'javascript', 'typescript', 'react', 'angular', 'vue',
            'node.js', 'django', 'flask', 'spring', 'express', 'sql', 'mongodb',
            'postgresql', 'aws', 'azure', 'docker', 'kubernetes', 'git', 'linux',
            'machine learning', 'deep learning', 'tensorflow', 'pytorch', 'scikit-learn',
            'html', 'css', 'bootstrap', 'sass', 'redux', 'graphql', 'rest api',
            'agile', 'scrum', 'ci/cd', 'jenkins', 'terraform', 'ansible'
        ]
        
        found_skills = []
        text_lower = text.lower()
        
        for skill in skill_keywords:
            if skill in text_lower:
                found_skills.append(skill.title())
        
        # Also look for skills section
        skills_section_pattern = r'(?:skills?|technical skills?|technologies?|proficiency)[:]\s*(.+?)(?:\n\n|\n[A-Z]|$)'
        match = re.search(skills_section_pattern, text, re.IGNORECASE | re.DOTALL)
        if match:
            skills_text = match.group(1)
            # Extract comma or bullet-separated skills
            skills_list = re.split(r'[,•\-\n]', skills_text)
            for skill in skills_list:
                skill = skill.strip()
                if len(skill) > 2 and len(skill) < 50:
                    found_skills.append(skill)
        
        return list(set(found_skills))  # Remove duplicates
    
    def _extract_skills_basic(self, text: str) -> List[str]:
        """Basic skills extraction without spaCy"""
        return self._extract_skills(None, text)
    
    def _extract_experience(self, doc, text: str) -> List[Dict]:
        """Extract work experience"""
        experience = []
        
        # Look for experience section
        exp_patterns = [
            r'(?:experience|work experience|employment|professional experience)[:]\s*(.+?)(?:\n\n\n|\n(?:education|projects|skills)|$)',
            r'(?:experience|work experience)[:]\s*(.+?)(?=\n\n\n|\n[A-Z][a-z]+\s*:)'
        ]
        
        exp_text = ""
        for pattern in exp_patterns:
            match = re.search(pattern, text, re.IGNORECASE | re.DOTALL)
            if match:
                exp_text = match.group(1)
                break
        
        if not exp_text:
            # Try to find job entries by common patterns
            job_pattern = r'([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\s*[-–—]\s*([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\s*[-–—]?\s*([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)?\s*\n(.+?)(?=\n\n|\n[A-Z][a-z]+\s*[-–—]|$)'
            matches = re.finditer(job_pattern, text, re.MULTILINE)
            for match in matches:
                experience.append({
                    "company": match.group(1) if match.groups() >= 1 else "Unknown",
                    "role": match.group(2) if match.groups() >= 2 else "Unknown",
                    "duration": match.group(3) if match.groups() >= 3 else "Unknown",
                    "description": match.group(4).strip() if match.groups() >= 4 else ""
                })
            return experience
        
        # Parse individual job entries
        job_entries = re.split(r'\n(?=[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\s*[-–—])', exp_text)
        
        for entry in job_entries:
            lines = entry.strip().split('\n')
            if len(lines) < 2:
                continue
            
            # Extract company, role, duration from first line
            first_line = lines[0]
            parts = re.split(r'\s*[-–—]\s*', first_line)
            
            role = parts[0] if len(parts) > 0 else "Unknown"
            company = parts[1] if len(parts) > 1 else "Unknown"
            duration = parts[2] if len(parts) > 2 else ""
            
            # Extract description
            description = '\n'.join(lines[1:]).strip()
            
            experience.append({
                "company": company.strip(),
                "role": role.strip(),
                "duration": duration.strip(),
                "description": description
            })
        
        return experience
    
    def _extract_education(self, doc, text: str) -> List[Dict]:
        """Extract education information"""
        education = []
        
        edu_pattern = r'(?:education|academic|qualifications)[:]\s*(.+?)(?:\n\n\n|\n(?:experience|projects|skills)|$)'
        match = re.search(edu_pattern, text, re.IGNORECASE | re.DOTALL)
        
        if match:
            edu_text = match.group(1)
            # Look for degree patterns
            degree_pattern = r'([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\s*[-–—]?\s*([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)?\s*[-–—]?\s*([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)?'
            matches = re.finditer(degree_pattern, edu_text)
            for match in matches:
                education.append({
                    "degree": match.group(1) if match.groups() >= 1 else "",
                    "field": match.group(2) if match.groups() >= 2 else "",
                    "institution": match.group(3) if match.groups() >= 3 else ""
                })
        
        return education
    
    def _extract_projects(self, doc, text: str) -> List[Dict]:
        """Extract project descriptions"""
        projects = []
        
        proj_pattern = r'(?:projects?|personal projects?|key projects?)[:]\s*(.+?)(?:\n\n\n|\n(?:education|experience|skills)|$)'
        match = re.search(proj_pattern, text, re.IGNORECASE | re.DOTALL)
        
        if match:
            proj_text = match.group(1)
            # Split by project titles (lines starting with capital letters)
            proj_entries = re.split(r'\n(?=[A-Z][a-z]+)', proj_text)
            
            for entry in proj_entries:
                lines = entry.strip().split('\n')
                if len(lines) >= 1:
                    title = lines[0].strip()
                    description = '\n'.join(lines[1:]).strip() if len(lines) > 1 else ""
                    projects.append({
                        "title": title,
                        "description": description
                    })
        
        return projects
    
    def _extract_certifications(self, text: str) -> List[str]:
        """Extract certifications"""
        certifications = []
        
        cert_pattern = r'(?:certifications?|certificates?)[:]\s*(.+?)(?:\n\n\n|\n(?:education|experience|projects)|$)'
        match = re.search(cert_pattern, text, re.IGNORECASE | re.DOTALL)
        
        if match:
            cert_text = match.group(1)
            certs = re.split(r'[,•\-\n]', cert_text)
            for cert in certs:
                cert = cert.strip()
                if len(cert) > 3:
                    certifications.append(cert)
        
        return certifications
    
    def _extract_soft_skills(self, doc, text: str) -> List[str]:
        """Extract soft skills indicators"""
        soft_skills_keywords = [
            'leadership', 'communication', 'teamwork', 'collaboration', 'problem-solving',
            'analytical', 'creative', 'adaptable', 'organized', 'detail-oriented',
            'self-motivated', 'proactive', 'mentoring', 'presentation', 'negotiation'
        ]
        
        found_skills = []
        text_lower = text.lower()
        
        for skill in soft_skills_keywords:
            if skill in text_lower:
                found_skills.append(skill.title())
        
        return list(set(found_skills))
