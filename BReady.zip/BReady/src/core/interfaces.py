"""
Interface definitions for modular component architecture
Allows easy swapping of implementations
"""
from abc import ABC, abstractmethod
from typing import Dict, List, Optional


class IParser(ABC):
    """Interface for parsers (resume and job description)"""
    
    @abstractmethod
    def parse_text(self, text: str) -> Dict:
        """Parse text and return structured data"""
        pass
    
    @abstractmethod
    def parse_file(self, file_path: str) -> Dict:
        """Parse file and return structured data"""
        pass


class IEmbeddingModel(ABC):
    """Interface for embedding models"""
    
    @abstractmethod
    def create_embeddings(self, texts: List[str]) -> List:
        """Create embeddings for texts"""
        pass
    
    @abstractmethod
    def get_dimension(self) -> int:
        """Get embedding dimension"""
        pass


class IRankingStrategy(ABC):
    """Interface for ranking strategies"""
    
    @abstractmethod
    def calculate_score(self, candidate: Dict, job: Dict) -> Dict:
        """Calculate ranking score for a candidate"""
        pass
    
    @abstractmethod
    def rank_candidates(self, candidates: List[Dict], job: Dict) -> List[Dict]:
        """Rank multiple candidates"""
        pass


class IReportGenerator(ABC):
    """Interface for report generators"""
    
    @abstractmethod
    def generate_report(self, candidate: Dict, job: Dict, score_data: Dict) -> str:
        """Generate evaluation report"""
        pass


class IVectorStore(ABC):
    """Interface for vector stores"""
    
    @abstractmethod
    def add_vectors(self, vectors, metadata: List[Dict] = None):
        """Add vectors to store"""
        pass
    
    @abstractmethod
    def search(self, query_vector, k: int = 10) -> List:
        """Search for similar vectors"""
        pass
    
    @abstractmethod
    def clear(self):
        """Clear all vectors"""
        pass


