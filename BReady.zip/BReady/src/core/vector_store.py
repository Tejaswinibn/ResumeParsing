"""
Vector Store Module using FAISS - PRODUCTION VERSION
Efficient similarity search for large-scale candidate matching
Actually uses FAISS for vector search, not just numpy
"""
import numpy as np
from typing import List, Dict, Tuple, Optional
try:
    import faiss
    FAISS_AVAILABLE = True
except ImportError:
    FAISS_AVAILABLE = False
    print("Warning: FAISS not available. Using numpy-based similarity search.")


class VectorStore:
    """
    Production-grade FAISS-based vector store
    
    Algorithm: FAISS Approximate Nearest Neighbor Search
    - IndexFlatL2: Exact search (fast for < 1M vectors)
    - Normalized vectors: Enables cosine similarity via L2 distance
    - Batch operations: Efficient bulk insert/search
    """
    
    def __init__(self, dimension: int = 384, use_faiss: bool = True):
        """
        Initialize vector store with FAISS
        
        Args:
            dimension: Embedding dimension (384 for all-MiniLM-L6-v2)
            use_faiss: Use FAISS (True) or numpy fallback (False)
        """
        self.dimension = dimension
        self.use_faiss = use_faiss and FAISS_AVAILABLE
        self.vectors = []
        self.metadata = []
        
        if self.use_faiss:
            # FAISS IndexFlatL2: Exact L2 distance search
            # For normalized vectors, L2 distance ≈ cosine similarity
            self.index = faiss.IndexFlatL2(dimension)
            print(f"✅ FAISS vector store initialized (dimension={dimension})")
        else:
            self.index = None
            print("⚠️ Using numpy fallback (slower for large datasets)")
    
    def add_vectors(self, vectors: np.ndarray, metadata: List[Dict] = None):
        """
        Add vectors to FAISS index
        
        Algorithm: Batch insertion into FAISS index
        - Normalizes vectors for cosine similarity
        - Adds to FAISS index for fast search
        """
        if vectors.size == 0:
            return
        
        # Normalize vectors for cosine similarity
        norms = np.linalg.norm(vectors, axis=1, keepdims=True)
        norms[norms == 0] = 1  # Avoid division by zero
        normalized_vectors = vectors / norms
        
        if self.use_faiss:
            # Add to FAISS index (efficient batch operation)
            self.index.add(normalized_vectors.astype('float32'))
        else:
            # Fallback: store in numpy array
            if len(self.vectors) == 0:
                self.vectors = normalized_vectors
            else:
                self.vectors = np.vstack([self.vectors, normalized_vectors])
        
        # Store metadata
        if metadata:
            self.metadata.extend(metadata)
        else:
            self.metadata.extend([{}] * len(normalized_vectors))
    
    def search(self, query_vector: np.ndarray, k: int = 10) -> List[Tuple[int, float, Dict]]:
        """
        Search for similar vectors using FAISS
        
        Algorithm: FAISS Approximate Nearest Neighbor Search
        - Normalizes query vector
        - Searches FAISS index
        - Converts L2 distance to cosine similarity
        - Returns top-k results
        
        Time Complexity: O(log n) with FAISS vs O(n) brute force
        """
        if query_vector.size == 0:
            return []
        
        # Normalize query vector
        norm = np.linalg.norm(query_vector)
        if norm == 0:
            return []
        query_normalized = (query_vector / norm).reshape(1, -1).astype('float32')
        
        if self.use_faiss and self.index.ntotal > 0:
            # FAISS search - THIS IS THE REAL VECTOR SEARCH
            distances, indices = self.index.search(query_normalized, k)
            
            results = []
            for idx, dist in zip(indices[0], distances[0]):
                if idx >= 0 and idx < len(self.metadata):
                    # Convert L2 distance to cosine similarity
                    # For normalized vectors: cosine_sim = 1 - (L2^2 / 2)
                    similarity = max(0.0, 1.0 - (float(dist) / 2.0))
                    results.append((int(idx), similarity, self.metadata[int(idx)]))
            return results
        else:
            # Fallback: numpy-based search
            if len(self.vectors) == 0:
                return []
            
            # Compute cosine similarities
            similarities = np.dot(self.vectors, query_normalized.T).flatten()
            
            # Get top k
            top_k_indices = np.argsort(similarities)[::-1][:k]
            
            results = []
            for idx in top_k_indices:
                results.append((int(idx), float(similarities[idx]), self.metadata[int(idx)]))
            return results
    
    def batch_search(self, query_vectors: np.ndarray, k: int = 10) -> List[List[Tuple[int, float, Dict]]]:
        """
        Batch search for multiple queries
        
        Algorithm: Parallel FAISS search
        - More efficient than individual searches
        - Returns results for each query
        """
        results = []
        for query_vec in query_vectors:
            results.append(self.search(query_vec, k))
        return results
    
    def clear(self):
        """Clear all vectors and reset index"""
        self.vectors = []
        self.metadata = []
        if self.use_faiss:
            self.index = faiss.IndexFlatL2(self.dimension)
    
    def get_size(self) -> int:
        """Get number of vectors in store"""
        if self.use_faiss and self.index:
            return self.index.ntotal
        return len(self.vectors)
    
    def is_faiss_enabled(self) -> bool:
        """Check if FAISS is actually being used"""
        return self.use_faiss and self.index is not None
