"""
Optimized Candidate Database - For Hundreds of Resumes
Uses indexing, caching, and batch operations for performance
"""
import json
import os
from typing import List, Dict, Optional, Set
from datetime import datetime
import hashlib
from collections import defaultdict
import pickle


class OptimizedCandidateDatabase:
    """
    Optimized database for handling hundreds of candidates efficiently
    - Indexed search
    - Cached results
    - Batch operations
    - Lazy loading
    """
    
    def __init__(self, db_path: str = "data/candidates_db.json"):
        """Initialize optimized candidate database"""
        self.db_path = db_path
        self.candidates = []
        self._indexes = {
            'by_id': {},
            'by_status': defaultdict(list),
            'by_skills': defaultdict(set),  # skill -> set of candidate IDs
            'by_experience_level': defaultdict(list),
            'search_index': {}  # Pre-built searchable text
        }
        self._cache = {}  # Cache for search results
        self._ensure_db_directory()
        self.load_database()
        self._build_indexes()
    
    def _ensure_db_directory(self):
        """Ensure database directory exists"""
        db_dir = os.path.dirname(self.db_path)
        if db_dir:
            os.makedirs(db_dir, exist_ok=True)
    
    def load_database(self):
        """Load candidates from database (optimized)"""
        if os.path.exists(self.db_path):
            try:
                with open(self.db_path, 'r', encoding='utf-8') as f:
                    self.candidates = json.load(f)
            except Exception as e:
                print(f"Error loading database: {e}")
                self.candidates = []
        else:
            self.candidates = []
    
    def _build_indexes(self):
        """Build indexes for fast search (called after loading)"""
        self._indexes = {
            'by_id': {},
            'by_status': defaultdict(list),
            'by_skills': defaultdict(set),
            'by_experience_level': defaultdict(list),
            'search_index': {}
        }
        
        for candidate in self.candidates:
            candidate_id = candidate.get('id')
            if not candidate_id:
                continue
            
            # Index by ID
            self._indexes['by_id'][candidate_id] = candidate
            
            # Index by status
            status = candidate.get('status', 'active')
            self._indexes['by_status'][status].append(candidate_id)
            
            # Index by skills
            skills = candidate.get('skills', [])
            for skill in skills:
                skill_lower = skill.lower()
                self._indexes['by_skills'][skill_lower].add(candidate_id)
            
            # Index by experience level
            exp_level = self._get_experience_level(candidate)
            self._indexes['by_experience_level'][exp_level].append(candidate_id)
            
            # Build search index (pre-computed searchable text)
            self._indexes['search_index'][candidate_id] = self._build_searchable_text(candidate)
    
    def _build_searchable_text(self, candidate: Dict) -> str:
        """Build searchable text index for candidate"""
        return " ".join([
            candidate.get('name', ''),
            " ".join(candidate.get('skills', [])),
            " ".join([exp.get('role', '') + " " + exp.get('company', '') 
                      for exp in candidate.get('experience', [])]),
            " ".join([edu.get('degree', '') for edu in candidate.get('education', [])])
        ]).lower()
    
    def _get_experience_level(self, candidate: Dict) -> str:
        """Get experience level for indexing"""
        experience = candidate.get('experience', [])
        if not experience:
            return 'junior'
        
        roles = [exp.get('role', '').lower() for exp in experience]
        roles_text = " ".join(roles)
        
        if any(word in roles_text for word in ['senior', 'lead', 'principal', 'architect']):
            return 'senior'
        elif any(word in roles_text for word in ['mid', 'intermediate']):
            return 'mid'
        else:
            return 'junior'
    
    def save_database(self):
        """Save candidates to database (optimized - only save when needed)"""
        try:
            # Use atomic write (write to temp, then rename)
            temp_path = self.db_path + '.tmp'
            with open(temp_path, 'w', encoding='utf-8') as f:
                json.dump(self.candidates, f, indent=2, ensure_ascii=False)
            os.replace(temp_path, self.db_path)
        except Exception as e:
            print(f"Error saving database: {e}")
    
    def add_candidate(self, candidate: Dict) -> str:
        """Add candidate to database (optimized with indexing)"""
        candidate_id = self._generate_candidate_id(candidate)
        
        # Check if exists using index
        if candidate_id in self._indexes['by_id']:
            # Update existing
            candidate['id'] = candidate_id
            candidate['updated_at'] = datetime.now().isoformat()
            candidate['created_at'] = self._indexes['by_id'][candidate_id].get('created_at', candidate['updated_at'])
            self.update_candidate(candidate_id, candidate)
            return candidate_id
        
        # Add new candidate
        candidate['id'] = candidate_id
        candidate['created_at'] = datetime.now().isoformat()
        candidate['updated_at'] = candidate['created_at']
        candidate['status'] = 'active'
        candidate['notes'] = []
        candidate['tags'] = []
        
        self.candidates.append(candidate)
        
        # Update indexes immediately
        self._indexes['by_id'][candidate_id] = candidate
        self._indexes['by_status']['active'].append(candidate_id)
        
        skills = candidate.get('skills', [])
        for skill in skills:
            self._indexes['by_skills'][skill.lower()].add(candidate_id)
        
        exp_level = self._get_experience_level(candidate)
        self._indexes['by_experience_level'][exp_level].append(candidate_id)
        self._indexes['search_index'][candidate_id] = self._build_searchable_text(candidate)
        
        # Save database
        self.save_database()
        return candidate_id
    
    def _generate_candidate_id(self, candidate: Dict) -> str:
        """Generate unique candidate ID"""
        email = candidate.get('email', '')
        name = candidate.get('name', '')
        if email:
            return hashlib.md5(email.encode()).hexdigest()[:12]
        elif name:
            return hashlib.md5(name.encode()).hexdigest()[:12]
        else:
            return hashlib.md5(str(candidate).encode()).hexdigest()[:12]
    
    def get_candidate_by_id(self, candidate_id: str) -> Optional[Dict]:
        """Get candidate by ID (optimized with index)"""
        return self._indexes['by_id'].get(candidate_id)
    
    def search_candidates(self, query: str = "", filters: Optional[Dict] = None, 
                         limit: Optional[int] = None, offset: int = 0) -> Dict:
        """
        Optimized search with pagination
        
        Returns:
            {
                'results': List[Dict],
                'total': int,
                'limit': int,
                'offset': int
            }
        """
        # Check cache
        cache_key = f"{query}_{str(filters)}_{limit}_{offset}"
        if cache_key in self._cache:
            return self._cache[cache_key]
        
        # Start with all candidate IDs
        candidate_ids = set(self._indexes['by_id'].keys())
        
        # Apply filters using indexes (fast!)
        if filters:
            candidate_ids = self._apply_filters_optimized(candidate_ids, filters)
        
        # Apply text search using pre-built index
        if query:
            query_lower = query.lower()
            matching_ids = set()
            for cid, search_text in self._indexes['search_index'].items():
                if query_lower in search_text:
                    matching_ids.add(cid)
            candidate_ids = candidate_ids.intersection(matching_ids)
        
        # Convert IDs to candidates
        results = [self._indexes['by_id'][cid] for cid in candidate_ids if cid in self._indexes['by_id']]
        
        # Sort by created_at (newest first)
        results.sort(key=lambda x: x.get('created_at', ''), reverse=True)
        
        total = len(results)
        
        # Pagination
        if limit:
            results = results[offset:offset + limit]
        
        result_dict = {
            'results': results,
            'total': total,
            'limit': limit,
            'offset': offset
        }
        
        # Cache result (limit cache size)
        if len(self._cache) > 100:
            self._cache.clear()
        self._cache[cache_key] = result_dict
        
        return result_dict
    
    def _apply_filters_optimized(self, candidate_ids: Set[str], filters: Dict) -> Set[str]:
        """Apply filters using indexes (much faster than iterating)"""
        filtered_ids = candidate_ids.copy()
        
        # Status filter (using index)
        if 'status' in filters:
            status = filters['status']
            status_ids = set(self._indexes['by_status'].get(status, []))
            filtered_ids = filtered_ids.intersection(status_ids)
        
        # Skills filter (using index)
        if 'skills' in filters:
            required_skills = [s.lower() for s in filters['skills']]
            skill_ids = set()
            for skill in required_skills:
                skill_ids.update(self._indexes['by_skills'].get(skill, set()))
            filtered_ids = filtered_ids.intersection(skill_ids)
        
        # Experience level filter (using index)
        if 'experience_level' in filters:
            level = filters['experience_level'].lower()
            exp_ids = set(self._indexes['by_experience_level'].get(level, []))
            filtered_ids = filtered_ids.intersection(exp_ids)
        
        # Years of experience (needs iteration, but on smaller set)
        if 'years_experience' in filters:
            min_years = filters['years_experience']
            filtered_ids = {cid for cid in filtered_ids 
                          if self._has_min_experience(self._indexes['by_id'][cid], min_years)}
        
        # Tags filter
        if 'tags' in filters:
            required_tags = filters['tags']
            filtered_ids = {cid for cid in filtered_ids
                          if any(tag in self._indexes['by_id'][cid].get('tags', []) 
                                for tag in required_tags)}
        
        return filtered_ids
    
    def _has_min_experience(self, candidate: Dict, min_years: int) -> bool:
        """Check minimum experience"""
        experience = candidate.get('experience', [])
        total_years = 0
        
        for exp in experience:
            duration = exp.get('duration', '')
            if 'year' in duration.lower():
                import re
                years_match = re.search(r'(\d+)\s*year', duration.lower())
                if years_match:
                    total_years += int(years_match.group(1))
        
        return total_years >= min_years
    
    def batch_add_candidates(self, candidates: List[Dict]) -> List[str]:
        """Batch add candidates (optimized)"""
        candidate_ids = []
        for candidate in candidates:
            candidate_id = self.add_candidate(candidate)
            candidate_ids.append(candidate_id)
        return candidate_ids
    
    def update_candidate(self, candidate_id: str, updates: Dict):
        """Update candidate (optimized with index update)"""
        if candidate_id not in self._indexes['by_id']:
            raise ValueError(f"Candidate {candidate_id} not found")
        
        candidate = self._indexes['by_id'][candidate_id]
        candidate.update(updates)
        candidate['updated_at'] = datetime.now().isoformat()
        
        # Update indexes
        old_status = candidate.get('status', 'active')
        new_status = updates.get('status', old_status)
        if new_status != old_status:
            if candidate_id in self._indexes['by_status'][old_status]:
                self._indexes['by_status'][old_status].remove(candidate_id)
            self._indexes['by_status'][new_status].append(candidate_id)
        
        # Update search index
        self._indexes['search_index'][candidate_id] = self._build_searchable_text(candidate)
        
        # Clear cache
        self._cache.clear()
        
        # Save (can be deferred for batch updates)
        self.save_database()
    
    def add_note(self, candidate_id: str, note: str, author: str = "Recruiter"):
        """Add note to candidate"""
        candidate = self.get_candidate_by_id(candidate_id)
        if candidate:
            if 'notes' not in candidate:
                candidate['notes'] = []
            candidate['notes'].append({
                'text': note,
                'author': author,
                'timestamp': datetime.now().isoformat()
            })
            self.update_candidate(candidate_id, candidate)
    
    def update_status(self, candidate_id: str, status: str):
        """Update candidate status"""
        self.update_candidate(candidate_id, {'status': status})
    
    def add_tag(self, candidate_id: str, tag: str):
        """Add tag to candidate"""
        candidate = self.get_candidate_by_id(candidate_id)
        if candidate:
            if 'tags' not in candidate:
                candidate['tags'] = []
            if tag not in candidate['tags']:
                candidate['tags'].append(tag)
                self.update_candidate(candidate_id, candidate)
    
    def get_all_candidates(self, limit: Optional[int] = None, offset: int = 0) -> Dict:
        """Get all candidates with pagination"""
        results = self.candidates.copy()
        results.sort(key=lambda x: x.get('created_at', ''), reverse=True)
        
        total = len(results)
        if limit:
            results = results[offset:offset + limit]
        
        return {
            'results': results,
            'total': total,
            'limit': limit,
            'offset': offset
        }
    
    def get_candidates_by_status(self, status: str, limit: Optional[int] = None, 
                                offset: int = 0) -> Dict:
        """Get candidates by status (optimized with index)"""
        candidate_ids = self._indexes['by_status'].get(status, [])
        results = [self._indexes['by_id'][cid] for cid in candidate_ids if cid in self._indexes['by_id']]
        
        total = len(results)
        if limit:
            results = results[offset:offset + limit]
        
        return {
            'results': results,
            'total': total,
            'limit': limit,
            'offset': offset
        }
    
    def get_statistics(self) -> Dict:
        """Get database statistics (fast with indexes)"""
        return {
            'total_candidates': len(self.candidates),
            'by_status': {status: len(ids) for status, ids in self._indexes['by_status'].items()},
            'by_experience_level': {level: len(ids) for level, ids in self._indexes['by_experience_level'].items()},
            'unique_skills': len(self._indexes['by_skills'])
        }

