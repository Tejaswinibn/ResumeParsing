"""
Semantic Analysis Module
Uses sentence transformers to create embeddings and compute semantic similarity
Supports both FAISS-based and numpy-based vector search
"""
from sentence_transformers import SentenceTransformer
import numpy as np
from typing import List, Dict, Tuple, Optional
import config
from vector_store import VectorStore
from skill_ontology import SkillOntology


class SemanticAnalyzer:
    """Analyze semantic similarity between candidates and job requirements"""
    
    def __init__(self, model_name: str = None, use_faiss: bool = True):
        """
        Initialize the semantic analyzer with a sentence transformer model
        
        Args:
            model_name: Name of the sentence transformer model
            use_faiss: Whether to use FAISS for vector search (if available)
        """
        self.model_name = model_name or config.EMBEDDING_MODEL
        print(f"Loading embedding model: {self.model_name}")
        self.model = SentenceTransformer(self.model_name)
        self.embedding_dim = self.model.get_sentence_embedding_dimension()
        print(f"Model loaded successfully! Embedding dimension: {self.embedding_dim}")
        
        # Initialize vector store for efficient search
        self.vector_store = VectorStore(dimension=self.embedding_dim, use_faiss=use_faiss)
        
        # Initialize skill ontology
        self.skill_ontology = SkillOntology()
    
    def create_embeddings(self, texts: List[str]) -> np.ndarray:
        """Create embeddings for a list of texts"""
        if not texts:
            return np.array([])
        return self.model.encode(texts, convert_to_numpy=True, show_progress_bar=False)
    
    def compute_similarity(self, text1: str, text2: str) -> float:
        """Compute cosine similarity between two texts"""
        embeddings = self.create_embeddings([text1, text2])
        if len(embeddings) < 2:
            return 0.0
        
        # Compute cosine similarity
        similarity = np.dot(embeddings[0], embeddings[1]) / (
            np.linalg.norm(embeddings[0]) * np.linalg.norm(embeddings[1])
        )
        return float(similarity)
    
    def compute_batch_similarity(self, texts1: List[str], texts2: List[str]) -> np.ndarray:
        """Compute similarity matrix between two lists of texts"""
        if not texts1 or not texts2:
            return np.array([])
        
        embeddings1 = self.create_embeddings(texts1)
        embeddings2 = self.create_embeddings(texts2)
        
        # Normalize embeddings
        embeddings1 = embeddings1 / np.linalg.norm(embeddings1, axis=1, keepdims=True)
        embeddings2 = embeddings2 / np.linalg.norm(embeddings2, axis=1, keepdims=True)
        
        # Compute cosine similarity matrix
        similarity_matrix = np.dot(embeddings1, embeddings2.T)
        return similarity_matrix
    
    def analyze_candidate_skills(self, candidate_skills: List[str], job_skills: List[str]) -> Dict:
        """Analyze skill similarity between candidate and job requirements"""
        if not candidate_skills or not job_skills:
            return {
                "similarity_score": 0.0,
                "matched_skills": [],
                "missing_skills": job_skills.copy(),
                "extra_skills": candidate_skills.copy()
            }
        
        # First, use skill ontology for enhanced matching
        ontology_result = self.skill_ontology.enhance_skill_matching(candidate_skills, job_skills)
        
        # Create skill strings for embedding
        candidate_skills_text = ", ".join(candidate_skills)
        job_skills_text = ", ".join(job_skills)
        
        # Overall similarity using embeddings
        overall_similarity = self.compute_similarity(candidate_skills_text, job_skills_text)
        
        # Individual skill matching using embeddings
        similarity_matrix = self.compute_batch_similarity(candidate_skills, job_skills)
        
        # Combine ontology and embedding results
        matched_skills = []
        missing_skills = job_skills.copy()
        extra_skills = candidate_skills.copy()
        
        # Process ontology matches
        for match in ontology_result["enhanced_matches"]:
            matched_skills.append({
                "job_skill": match["job_skill"],
                "candidate_skill": match["candidate_skill"],
                "similarity": match["confidence"],
                "match_type": match["match_type"]
            })
            if match["job_skill"] in missing_skills:
                missing_skills.remove(match["job_skill"])
            if match["candidate_skill"] in extra_skills:
                extra_skills.remove(match["candidate_skill"])
        
        # Add embedding-based matches for skills not found by ontology
        if similarity_matrix.size > 0:
            for i, job_skill in enumerate(job_skills):
                if job_skill in missing_skills:  # Only check if not already matched
                    if i < similarity_matrix.shape[1]:
                        best_match_idx = np.argmax(similarity_matrix[:, i])
                        best_similarity = similarity_matrix[best_match_idx, i]
                        
                        if best_similarity > 0.5 and best_match_idx < len(candidate_skills):
                            matched_skill = candidate_skills[best_match_idx]
                            matched_skills.append({
                                "job_skill": job_skill,
                                "candidate_skill": matched_skill,
                                "similarity": float(best_similarity),
                                "match_type": "semantic"
                            })
                            if job_skill in missing_skills:
                                missing_skills.remove(job_skill)
                            if matched_skill in extra_skills:
                                extra_skills.remove(matched_skill)
        
        return {
            "similarity_score": float(overall_similarity),
            "matched_skills": matched_skills,
            "missing_skills": missing_skills,
            "extra_skills": extra_skills,
            "ontology_matches": ontology_result["match_count"]
        }
    
    def analyze_projects(self, candidate_projects: List[Dict], job_responsibilities: List[str]) -> Dict:
        """Analyze how well candidate projects match job responsibilities"""
        if not candidate_projects or not job_responsibilities:
            return {
                "similarity_score": 0.0,
                "relevant_projects": []
            }
        
        # Create project descriptions
        project_descriptions = []
        for project in candidate_projects:
            desc = f"{project.get('title', '')} {project.get('description', '')}"
            project_descriptions.append(desc)
        
        # Compute similarity
        similarity_matrix = self.compute_batch_similarity(project_descriptions, job_responsibilities)
        
        # Find relevant projects
        relevant_projects = []
        if similarity_matrix.size > 0:
            for i, project in enumerate(candidate_projects):
                if i < similarity_matrix.shape[0]:
                    max_similarity = float(np.max(similarity_matrix[i, :]))
                    if max_similarity > 0.3:  # Lower threshold for projects
                        relevant_projects.append({
                            "project": project,
                            "max_similarity": max_similarity
                        })
        
        # Overall similarity score
        if similarity_matrix.size > 0:
            overall_similarity = float(np.mean(similarity_matrix))
        else:
            overall_similarity = 0.0
        
        return {
            "similarity_score": overall_similarity,
            "relevant_projects": relevant_projects
        }
    
    def analyze_experience(self, candidate_experience: List[Dict], job_requirements: List[str]) -> Dict:
        """Analyze experience relevance"""
        if not candidate_experience or not job_requirements:
            return {
                "similarity_score": 0.0,
                "relevant_experience": []
            }
        
        # Create experience descriptions
        experience_descriptions = []
        for exp in candidate_experience:
            desc = f"{exp.get('role', '')} at {exp.get('company', '')}. {exp.get('description', '')}"
            experience_descriptions.append(desc)
        
        # Compute similarity
        similarity_matrix = self.compute_batch_similarity(experience_descriptions, job_requirements)
        
        # Find relevant experience
        relevant_experience = []
        if similarity_matrix.size > 0:
            for i, exp in enumerate(candidate_experience):
                if i < similarity_matrix.shape[0]:
                    max_similarity = float(np.max(similarity_matrix[i, :]))
                    if max_similarity > 0.3:
                        relevant_experience.append({
                            "experience": exp,
                            "max_similarity": max_similarity
                        })
        
        # Overall similarity score
        if similarity_matrix.size > 0:
            overall_similarity = float(np.mean(similarity_matrix))
        else:
            overall_similarity = 0.0
        
        return {
            "similarity_score": overall_similarity,
            "relevant_experience": relevant_experience
        }

