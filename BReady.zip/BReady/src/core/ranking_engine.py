"""
Candidate Ranking Engine
Ranks candidates based on multiple factors using weighted scoring
Modular design allows swapping ranking strategies
"""
import sys
import os
from typing import List, Dict, Optional

# Add project root to path
project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, project_root)

import config
from src.core.semantic_analyzer import SemanticAnalyzer
from src.core.interfaces import IRankingStrategy


class RankingEngine(IRankingStrategy):
    """Rank candidates based on job requirements"""
    
    def __init__(self, semantic_analyzer: Optional[SemanticAnalyzer] = None, weights: Optional[Dict] = None):
        """
        Initialize ranking engine
        
        Args:
            semantic_analyzer: Optional semantic analyzer instance (creates new if None)
            weights: Optional custom ranking weights (uses config if None)
        """
        self.semantic_analyzer = semantic_analyzer or SemanticAnalyzer()
        self.weights = weights or config.RANKING_WEIGHTS
    
    def rank_candidates(self, candidates: List[Dict], job_description: Dict) -> List[Dict]:
        """Rank candidates based on job requirements"""
        ranked_candidates = []
        
        for candidate in candidates:
            score_data = self._calculate_score(candidate, job_description)
            ranked_candidates.append({
                "candidate": candidate,
                "score": score_data["total_score"],
                "score_breakdown": score_data
            })
        
        # Sort by total score (descending)
        ranked_candidates.sort(key=lambda x: x["score"], reverse=True)
        
        return ranked_candidates
    
    def calculate_score(self, candidate: Dict, job: Dict) -> Dict:
        """Calculate ranking score for a candidate (implements IRankingStrategy)"""
        return self._calculate_score(candidate, job)
    
    def _calculate_score(self, candidate: Dict, job: Dict) -> Dict:
        """Calculate weighted score for a candidate"""
        # Skill similarity analysis
        skill_analysis = self.semantic_analyzer.analyze_candidate_skills(
            candidate.get("skills", []),
            job.get("required_skills", [])
        )
        skill_score = skill_analysis["similarity_score"]
        
        # Experience relevance analysis
        experience_analysis = self.semantic_analyzer.analyze_experience(
            candidate.get("experience", []),
            job.get("responsibilities", []) + job.get("requirements", [])
        )
        experience_score = experience_analysis["similarity_score"]
        
        # Project similarity analysis
        project_analysis = self.semantic_analyzer.analyze_projects(
            candidate.get("projects", []),
            job.get("responsibilities", [])
        )
        project_score = project_analysis["similarity_score"]
        
        # Education and certifications score
        education_score = self._calculate_education_score(candidate, job)
        
        # Soft skills score
        soft_skills_score = self._calculate_soft_skills_score(
            candidate.get("soft_skills", []),
            job.get("soft_skills", [])
        )
        
        # Calculate weighted total score
        total_score = (
            skill_score * self.weights["skill_similarity"] +
            experience_score * self.weights["experience_relevance"] +
            project_score * self.weights["project_similarity"] +
            education_score * self.weights["education_certifications"] +
            soft_skills_score * self.weights["soft_skills"]
        )
        
        return {
            "total_score": total_score,
            "skill_similarity": skill_score,
            "experience_relevance": experience_score,
            "project_similarity": project_score,
            "education_certifications": education_score,
            "soft_skills": soft_skills_score,
            "skill_analysis": skill_analysis,
            "experience_analysis": experience_analysis,
            "project_analysis": project_analysis
        }
    
    def _calculate_education_score(self, candidate: Dict, job: Dict) -> float:
        """Calculate education and certifications score"""
        score = 0.0
        
        # Check for relevant certifications
        certifications = candidate.get("certifications", [])
        if certifications:
            # Having certifications is a plus
            score += 0.3
        
        # Check for education
        education = candidate.get("education", [])
        if education:
            # Having education listed is a plus
            score += 0.2
        
        # Check for degree-related keywords in job description
        job_text = job.get("raw_text", "").lower()
        if any(keyword in job_text for keyword in ["degree", "bachelor", "master", "phd", "education"]):
            if education:
                score += 0.5
        
        return min(score, 1.0)
    
    def _calculate_soft_skills_score(self, candidate_skills: List[str], job_skills: List[str]) -> float:
        """Calculate soft skills matching score"""
        if not job_skills:
            return 0.5  # Neutral if no soft skills specified
        
        if not candidate_skills:
            return 0.0
        
        # Simple keyword matching for soft skills
        candidate_skills_lower = [s.lower() for s in candidate_skills]
        job_skills_lower = [s.lower() for s in job_skills]
        
        matches = sum(1 for skill in job_skills_lower if any(cs in skill or skill in cs for cs in candidate_skills_lower))
        
        return matches / len(job_skills) if job_skills else 0.0

