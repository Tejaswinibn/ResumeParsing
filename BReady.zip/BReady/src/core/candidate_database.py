"""
Candidate Database Module - Like Lilyhire.com
Optimized for hundreds of resumes with indexing and caching
"""
import json
import os
from typing import List, Dict, Optional
from datetime import datetime
import hashlib

# Use optimized version if available
try:
    from src.core.optimized_database import OptimizedCandidateDatabase
    CandidateDatabase = OptimizedCandidateDatabase  # Use optimized version
except ImportError:
    # Fallback to basic version
    class CandidateDatabase:
    """
    Candidate database for recruiter sourcing
    Similar to Lilyhire.com's candidate management
    """
    
    def __init__(self, db_path: str = "data/candidates_db.json"):
        """Initialize candidate database"""
        self.db_path = db_path
        self.candidates = []
        self._ensure_db_directory()
        self.load_database()
    
    def _ensure_db_directory(self):
        """Ensure database directory exists"""
        db_dir = os.path.dirname(self.db_path)
        if db_dir:  # Only create if path has directory
            os.makedirs(db_dir, exist_ok=True)
    
    def load_database(self):
        """Load candidates from database"""
        if os.path.exists(self.db_path):
            try:
                with open(self.db_path, 'r', encoding='utf-8') as f:
                    self.candidates = json.load(f)
            except Exception as e:
                print(f"Error loading database: {e}")
                self.candidates = []
        else:
            self.candidates = []
    
    def save_database(self):
        """Save candidates to database"""
        try:
            with open(self.db_path, 'w', encoding='utf-8') as f:
                json.dump(self.candidates, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"Error saving database: {e}")
    
    def add_candidate(self, candidate: Dict) -> str:
        """Add candidate to database"""
        # Generate unique ID
        candidate_id = self._generate_candidate_id(candidate)
        
        # Check if candidate already exists
        existing = self.get_candidate_by_id(candidate_id)
        if existing:
            # Update existing candidate
            candidate['id'] = candidate_id
            candidate['updated_at'] = datetime.now().isoformat()
            candidate['created_at'] = existing.get('created_at', candidate['updated_at'])
            self.update_candidate(candidate_id, candidate)
            return candidate_id
        
        # Add new candidate
        candidate['id'] = candidate_id
        candidate['created_at'] = datetime.now().isoformat()
        candidate['updated_at'] = candidate['created_at']
        candidate['status'] = 'active'  # active, shortlisted, rejected, hired
        candidate['notes'] = []
        candidate['tags'] = []
        
        self.candidates.append(candidate)
        self.save_database()
        return candidate_id
    
    def _generate_candidate_id(self, candidate: Dict) -> str:
        """Generate unique candidate ID based on email or name"""
        email = candidate.get('email', '')
        name = candidate.get('name', '')
        if email:
            return hashlib.md5(email.encode()).hexdigest()[:12]
        elif name:
            return hashlib.md5(name.encode()).hexdigest()[:12]
        else:
            return hashlib.md5(str(candidate).encode()).hexdigest()[:12]
    
    def get_candidate_by_id(self, candidate_id: str) -> Optional[Dict]:
        """Get candidate by ID"""
        for candidate in self.candidates:
            if candidate.get('id') == candidate_id:
                return candidate
        return None
    
    def search_candidates(self, query: str, filters: Optional[Dict] = None) -> List[Dict]:
        """
        Search candidates using NLP-based filters (like Lilyhire.com)
        
        Args:
            query: Search query (skills, experience, etc.)
            filters: Advanced filters (experience_level, skills, location, etc.)
        """
        results = self.candidates.copy()
        
        # Text search
        if query:
            query_lower = query.lower()
            filtered_results = []
            for candidate in results:
                # Search in name, skills, experience, education
                searchable_text = " ".join([
                    candidate.get('name', ''),
                    " ".join(candidate.get('skills', [])),
                    " ".join([exp.get('role', '') + " " + exp.get('company', '') 
                              for exp in candidate.get('experience', [])]),
                    " ".join([edu.get('degree', '') for edu in candidate.get('education', [])])
                ]).lower()
                
                if query_lower in searchable_text:
                    filtered_results.append(candidate)
            results = filtered_results
        
        # Apply filters
        if filters:
            results = self._apply_filters(results, filters)
        
        return results
    
    def _apply_filters(self, candidates: List[Dict], filters: Dict) -> List[Dict]:
        """Apply advanced NLP filters (like Lilyhire.com)"""
        filtered = candidates
        
        # Experience level filter
        if 'experience_level' in filters:
            level = filters['experience_level'].lower()
            filtered = [c for c in filtered if self._matches_experience_level(c, level)]
        
        # Skills filter
        if 'skills' in filters:
            required_skills = [s.lower() for s in filters['skills']]
            filtered = [c for c in filtered if self._has_skills(c, required_skills)]
        
        # Location filter
        if 'location' in filters:
            location = filters['location'].lower()
            filtered = [c for c in filtered if self._matches_location(c, location)]
        
        # Years of experience filter
        if 'years_experience' in filters:
            min_years = filters['years_experience']
            filtered = [c for c in filtered if self._has_min_experience(c, min_years)]
        
        # Status filter
        if 'status' in filters:
            status = filters['status']
            filtered = [c for c in filtered if c.get('status') == status]
        
        # Tags filter
        if 'tags' in filters:
            required_tags = filters['tags']
            filtered = [c for c in filtered if any(tag in c.get('tags', []) for tag in required_tags)]
        
        return filtered
    
    def _matches_experience_level(self, candidate: Dict, level: str) -> bool:
        """Check if candidate matches experience level"""
        experience = candidate.get('experience', [])
        if not experience:
            return level == 'entry' or level == 'junior'
        
        roles = [exp.get('role', '').lower() for exp in experience]
        
        if level == 'senior':
            return any(word in " ".join(roles) for word in ['senior', 'lead', 'principal', 'architect'])
        elif level == 'mid':
            return any(word in " ".join(roles) for word in ['mid', 'intermediate', 'engineer', 'developer'])
        elif level in ['junior', 'entry']:
            return any(word in " ".join(roles) for word in ['junior', 'entry', 'associate'])
        
        return True
    
    def _has_skills(self, candidate: Dict, required_skills: List[str]) -> bool:
        """Check if candidate has required skills"""
        candidate_skills = [s.lower() for s in candidate.get('skills', [])]
        return any(req_skill in " ".join(candidate_skills) for req_skill in required_skills)
    
    def _matches_location(self, candidate: Dict, location: str) -> bool:
        """Check if candidate matches location (basic implementation)"""
        # This would need location extraction from resume
        # For now, return True (all candidates match)
        return True
    
    def _has_min_experience(self, candidate: Dict, min_years: int) -> bool:
        """Check if candidate has minimum years of experience"""
        experience = candidate.get('experience', [])
        total_years = 0
        
        for exp in experience:
            duration = exp.get('duration', '')
            # Simple extraction (would need better parsing)
            if 'year' in duration.lower():
                import re
                years_match = re.search(r'(\d+)\s*year', duration.lower())
                if years_match:
                    total_years += int(years_match.group(1))
        
        return total_years >= min_years
    
    def update_candidate(self, candidate_id: str, updates: Dict):
        """Update candidate information"""
        for i, candidate in enumerate(self.candidates):
            if candidate.get('id') == candidate_id:
                self.candidates[i].update(updates)
                self.candidates[i]['updated_at'] = datetime.now().isoformat()
                self.save_database()
                return
        raise ValueError(f"Candidate {candidate_id} not found")
    
    def add_note(self, candidate_id: str, note: str, author: str = "Recruiter"):
        """Add note to candidate (CRM-like feature)"""
        candidate = self.get_candidate_by_id(candidate_id)
        if candidate:
            if 'notes' not in candidate:
                candidate['notes'] = []
            candidate['notes'].append({
                'text': note,
                'author': author,
                'timestamp': datetime.now().isoformat()
            })
            self.update_candidate(candidate_id, candidate)
    
    def update_status(self, candidate_id: str, status: str):
        """Update candidate status (active, shortlisted, rejected, hired)"""
        self.update_candidate(candidate_id, {'status': status})
    
    def add_tag(self, candidate_id: str, tag: str):
        """Add tag to candidate"""
        candidate = self.get_candidate_by_id(candidate_id)
        if candidate:
            if 'tags' not in candidate:
                candidate['tags'] = []
            if tag not in candidate['tags']:
                candidate['tags'].append(tag)
                self.update_candidate(candidate_id, candidate)
    
    def get_all_candidates(self) -> List[Dict]:
        """Get all candidates"""
        return self.candidates
    
    def get_candidates_by_status(self, status: str) -> List[Dict]:
        """Get candidates by status"""
        return [c for c in self.candidates if c.get('status') == status]
    
    def delete_candidate(self, candidate_id: str):
        """Delete candidate from database"""
        self.candidates = [c for c in self.candidates if c.get('id') != candidate_id]
        self.save_database()

