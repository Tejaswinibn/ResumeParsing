"""
Explainable AI Report Generator
Generates human-readable reports explaining candidate rankings
"""
import sys
import os
from typing import Dict, Optional

# Add project root to path
project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, project_root)

import config


class ReportGenerator:
    """Generate explainable reports for candidate evaluations"""
    
    def __init__(self):
        self.model = config.OPENAI_MODEL
        self.use_openai = bool(config.OPENAI_API_KEY)
    
    def generate_report(self, candidate: Dict, job: Dict, score_data: Dict) -> str:
        """Generate a comprehensive report for a candidate"""
        if self.use_openai:
            return self._generate_openai_report(candidate, job, score_data)
        else:
            return self._generate_template_report(candidate, job, score_data)
    
    def _generate_openai_report(self, candidate: Dict, job: Dict, score_data: Dict) -> str:
        """Generate report using OpenAI API"""
        try:
            from openai import OpenAI
            client = OpenAI(api_key=config.OPENAI_API_KEY)
            
            prompt = self._create_prompt(candidate, job, score_data)
            
            response = client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are an expert recruitment analyst. Generate clear, professional, and insightful candidate evaluation reports."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=1000,
                temperature=0.7
            )
            
            return response.choices[0].message.content
        except Exception as e:
            print(f"Error generating OpenAI report: {e}")
            return self._generate_template_report(candidate, job, score_data)
    
    def _create_prompt(self, candidate: Dict, job: Dict, score_data: Dict) -> str:
        """Create prompt for OpenAI"""
        candidate_name = candidate.get("name", "Candidate")
        job_title = job.get("title", "Position")
        total_score = score_data.get("total_score", 0.0)
        
        skill_analysis = score_data.get("skill_analysis", {})
        matched_skills = [m.get("candidate_skill") for m in skill_analysis.get("matched_skills", [])]
        missing_skills = skill_analysis.get("missing_skills", [])
        
        experience_analysis = score_data.get("experience_analysis", {})
        relevant_experience = experience_analysis.get("relevant_experience", [])
        
        project_analysis = score_data.get("project_analysis", {})
        relevant_projects = project_analysis.get("relevant_projects", [])
        
        prompt = f"""
Generate a professional candidate evaluation report for {candidate_name} applying for {job_title}.

Overall Fit Score: {total_score:.2%}

Candidate Skills: {', '.join(candidate.get('skills', [])[:10])}
Matched Skills: {', '.join(matched_skills[:10])}
Missing Skills: {', '.join(missing_skills[:10])}

Experience: {len(candidate.get('experience', []))} positions listed
Relevant Experience: {len(relevant_experience)} positions match job requirements

Projects: {len(candidate.get('projects', []))} projects listed
Relevant Projects: {len(relevant_projects)} projects align with job responsibilities

Please provide:
1. A brief summary of why this candidate is/isn't a good fit
2. Key strengths (specific skills, experiences, projects)
3. Gaps or weaknesses relative to job requirements
4. Recommendations (hire, consider, or suggest alternative roles/upskilling)

Keep the report professional, concise, and actionable.
"""
        return prompt
    
    def _generate_template_report(self, candidate: Dict, job: Dict, score_data: Dict) -> str:
        """Generate report using template (fallback when OpenAI not available)"""
        candidate_name = candidate.get("name", "Candidate")
        job_title = job.get("title", "Position")
        total_score = score_data.get("total_score", 0.0)
        
        skill_analysis = score_data.get("skill_analysis", {})
        matched_skills = [m.get("candidate_skill") for m in skill_analysis.get("matched_skills", [])]
        missing_skills = skill_analysis.get("missing_skills", [])
        
        experience_analysis = score_data.get("experience_analysis", {})
        project_analysis = score_data.get("project_analysis", {})
        
        report = f"""
# Candidate Evaluation Report: {candidate_name}
## Position: {job_title}

### Overall Fit Score: {total_score:.1%}

---

## Executive Summary
{'This candidate shows strong alignment with the job requirements.' if total_score >= 0.7 else 'This candidate has moderate alignment with the job requirements.' if total_score >= 0.5 else 'This candidate has limited alignment with the job requirements.'}

---

## Key Strengths

### Skills Match
- **Matched Skills**: {', '.join(matched_skills[:10]) if matched_skills else 'None identified'}
- **Skill Similarity Score**: {skill_analysis.get('similarity_score', 0):.1%}

### Experience Relevance
- **Relevant Experience Positions**: {len(experience_analysis.get('relevant_experience', []))}
- **Experience Relevance Score**: {score_data.get('experience_relevance', 0):.1%}

### Project Alignment
- **Relevant Projects**: {len(project_analysis.get('relevant_projects', []))}
- **Project Similarity Score**: {score_data.get('project_similarity', 0):.1%}

---

## Gaps and Weaknesses

### Missing Skills
{', '.join(missing_skills[:10]) if missing_skills else 'No major skill gaps identified'}

### Score Breakdown
- Skill Similarity: {score_data.get('skill_similarity', 0):.1%}
- Experience Relevance: {score_data.get('experience_relevance', 0):.1%}
- Project Similarity: {score_data.get('project_similarity', 0):.1%}
- Education/Certifications: {score_data.get('education_certifications', 0):.1%}
- Soft Skills: {score_data.get('soft_skills', 0):.1%}

---

## Recommendations

"""
        
        if total_score >= 0.7:
            report += "**Recommendation: Strong Candidate - Proceed to Interview**\n\n"
            report += "This candidate demonstrates strong alignment with the role requirements. Consider scheduling an interview to assess cultural fit and communication skills."
        elif total_score >= 0.5:
            report += "**Recommendation: Consider - Review Additional Qualifications**\n\n"
            report += "This candidate shows moderate fit. Review their portfolio and consider a screening call to assess potential and learning ability."
        else:
            report += "**Recommendation: Not Recommended - Consider Alternative Roles**\n\n"
            report += "This candidate has limited alignment with the current role. However, they may be suitable for a different position or could benefit from upskilling in specific areas."
        
        if missing_skills:
            report += f"\n### Suggested Upskilling Areas\n"
            report += f"If considering this candidate, focus on developing: {', '.join(missing_skills[:5])}\n"
        
        return report

