"""
Human-Like Analysis Engine
Mimics human recruiter thinking: contextual understanding, career trajectory,
problem-solving evidence, transferable potential, and holistic fit assessment
"""
import sys
import os
import re
from typing import Dict, List, Optional, Tuple
import numpy as np
from datetime import datetime

# Add project root to path
project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, project_root)

from src.core.semantic_analyzer import SemanticAnalyzer


class HumanAnalyzer:
    """
    Human-like candidate analysis that goes beyond keyword matching
    
    Analyzes:
    - Career trajectory and growth patterns
    - Problem-solving approach and evidence
    - Transferable skills and learning potential
    - Impact and achievements (quantifiable)
    - Contextual skill application
    - Domain adaptability
    - Experience depth vs breadth
    - Cultural and communication fit signals
    """
    
    def __init__(self, semantic_analyzer: Optional[SemanticAnalyzer] = None):
        self.semantic_analyzer = semantic_analyzer or SemanticAnalyzer()
        
        # Impact indicators (quantifiable achievements)
        self.impact_patterns = [
            r'increased\s+by\s+(\d+)%',
            r'reduced\s+by\s+(\d+)%',
            r'improved\s+by\s+(\d+)%',
            r'saved\s+\$?(\d+)',
            r'managed\s+(\d+)\s+',
            r'led\s+(\d+)\s+',
            r'achieved\s+(\d+)%',
            r'grew\s+by\s+(\d+)%',
            r'decreased\s+by\s+(\d+)%',
            r'optimized\s+.*?(\d+)%',
            r'scaled\s+to\s+(\d+)',
        ]
        
        # Problem-solving indicators
        self.problem_solving_keywords = [
            'solved', 'resolved', 'fixed', 'debugged', 'optimized',
            'improved', 'enhanced', 'refactored', 'architected',
            'designed', 'implemented', 'developed', 'created',
            'built', 'established', 'introduced', 'innovated'
        ]
        
        # Leadership and collaboration indicators
        self.leadership_keywords = [
            'led', 'managed', 'mentored', 'trained', 'coordinated',
            'collaborated', 'worked with', 'team of', 'cross-functional',
            'stakeholders', 'presented', 'communicated'
        ]
    
    def analyze_candidate_holistically(self, candidate: Dict, job: Dict) -> Dict:
        """
        Comprehensive human-like analysis of candidate fit
        
        Returns deep insights beyond keyword matching
        """
        analysis = {
            # Core human-like assessments
            "career_trajectory": self._analyze_career_trajectory(candidate),
            "problem_solving_evidence": self._analyze_problem_solving(candidate, job),
            "impact_and_achievements": self._analyze_impact(candidate),
            "transferable_potential": self._analyze_transferable_potential(candidate, job),
            "contextual_skill_application": self._analyze_contextual_skills(candidate, job),
            "learning_potential": self._analyze_learning_potential(candidate),
            "domain_adaptability": self._analyze_domain_adaptability(candidate, job),
            "experience_depth": self._analyze_experience_depth(candidate, job),
            "communication_signals": self._analyze_communication_signals(candidate),
            "cultural_fit_indicators": self._analyze_cultural_fit(candidate, job),
            
            # Overall human-like score
            "human_like_score": 0.0,
            "human_like_insights": []
        }
        
        # Calculate holistic human-like score
        analysis["human_like_score"] = self._calculate_human_like_score(analysis)
        analysis["human_like_insights"] = self._generate_human_insights(analysis, candidate, job)
        
        return analysis
    
    def _analyze_career_trajectory(self, candidate: Dict) -> Dict:
        """
        Analyze career progression and growth patterns
        Human recruiters look for: upward mobility, increasing responsibility, skill expansion
        """
        experience = candidate.get("experience", [])
        if not experience:
            return {"score": 0.0, "pattern": "no_experience", "indicators": []}
        
        trajectory_signals = []
        score = 0.0
        
        # Check for role progression (Junior → Mid → Senior)
        roles = [exp.get("role", "").lower() for exp in experience]
        role_progression = []
        
        for role in roles:
            if any(word in role for word in ["junior", "jr", "entry", "associate"]):
                role_progression.append("junior")
            elif any(word in role for word in ["senior", "sr", "lead", "principal", "architect"]):
                role_progression.append("senior")
            elif any(word in role for word in ["mid", "intermediate", "engineer", "developer"]):
                role_progression.append("mid")
        
        # Detect upward trajectory
        if len(role_progression) >= 2:
            if role_progression[-1] == "senior" and role_progression[0] in ["junior", "mid"]:
                trajectory_signals.append("Clear upward career progression")
                score += 0.3
            elif "senior" in role_progression or "lead" in role_progression:
                trajectory_signals.append("Senior-level experience")
                score += 0.2
        
        # Check for increasing responsibility (team size, scope)
        for exp in experience:
            desc = exp.get("description", "").lower()
            if any(word in desc for word in ["team", "managed", "led", "mentored"]):
                trajectory_signals.append("Leadership and management experience")
                score += 0.2
                break
        
        # Check for skill expansion across roles
        all_skills = []
        for exp in experience:
            desc = exp.get("description", "").lower()
            # Extract technology mentions
            tech_keywords = ["python", "java", "react", "aws", "docker", "kubernetes", "ml", "ai"]
            for tech in tech_keywords:
                if tech in desc and tech not in all_skills:
                    all_skills.append(tech)
        
        if len(all_skills) >= 5:
            trajectory_signals.append("Diverse skill expansion across roles")
            score += 0.2
        
        # Check for company prestige/scale progression
        companies = [exp.get("company", "") for exp in experience]
        if len(companies) >= 2:
            # Simple heuristic: more companies = more experience (but not too many = job hopper)
            if 2 <= len(companies) <= 4:
                trajectory_signals.append("Reasonable career moves")
                score += 0.1
        
        return {
            "score": min(score, 1.0),
            "pattern": "upward" if score > 0.5 else "stable" if score > 0.2 else "unclear",
            "indicators": trajectory_signals,
            "role_progression": role_progression
        }
    
    def _analyze_problem_solving(self, candidate: Dict, job: Dict) -> Dict:
        """
        Analyze problem-solving approach and evidence
        Human recruiters look for: how they describe challenges, solutions, impact
        """
        all_text = candidate.get("raw_text", "").lower()
        experience = candidate.get("experience", [])
        projects = candidate.get("projects", [])
        
        problem_solving_evidence = []
        score = 0.0
        
        # Count problem-solving keywords in context
        problem_solving_count = sum(1 for keyword in self.problem_solving_keywords if keyword in all_text)
        
        if problem_solving_count >= 5:
            problem_solving_evidence.append(f"Strong problem-solving language ({problem_solving_count} instances)")
            score += 0.3
        elif problem_solving_count >= 2:
            problem_solving_evidence.append(f"Moderate problem-solving evidence ({problem_solving_count} instances)")
            score += 0.15
        
        # Look for specific problem-solving patterns in descriptions
        for exp in experience:
            desc = exp.get("description", "").lower()
            # Check for action-oriented problem solving
            if any(phrase in desc for phrase in ["solved", "resolved", "fixed", "optimized", "improved"]):
                problem_solving_evidence.append("Action-oriented problem solving in experience")
                score += 0.2
                break
        
        # Check projects for problem-solving evidence
        for project in projects:
            desc = project.get("description", "").lower()
            if any(keyword in desc for keyword in ["challenge", "problem", "solution", "built", "created"]):
                problem_solving_evidence.append("Problem-solving demonstrated in projects")
                score += 0.15
                break
        
        # Semantic analysis: how well do their problem-solving descriptions match job challenges?
        job_responsibilities = job.get("responsibilities", [])
        if job_responsibilities:
            # Extract problem-solving context from job
            job_problem_context = " ".join(job_responsibilities).lower()
            
            # Compare candidate's problem-solving language with job requirements
            candidate_problem_context = " ".join([
                exp.get("description", "") for exp in experience
            ] + [proj.get("description", "") for proj in projects]).lower()
            
            if candidate_problem_context and job_problem_context:
                similarity = self.semantic_analyzer.compute_similarity(
                    candidate_problem_context[:500],  # Limit length
                    job_problem_context[:500]
                )
                if similarity > 0.6:
                    problem_solving_evidence.append("Problem-solving approach aligns with job requirements")
                    score += 0.2
        
        return {
            "score": min(score, 1.0),
            "evidence_count": problem_solving_count,
            "indicators": problem_solving_evidence
        }
    
    def _analyze_impact(self, candidate: Dict) -> Dict:
        """
        Analyze quantifiable impact and achievements
        Human recruiters value: metrics, results, measurable outcomes
        """
        all_text = candidate.get("raw_text", "")
        experience = candidate.get("experience", [])
        projects = candidate.get("projects", [])
        
        impact_metrics = []
        score = 0.0
        
        # Search for quantifiable achievements
        for pattern in self.impact_patterns:
            matches = re.finditer(pattern, all_text, re.IGNORECASE)
            for match in matches:
                value = match.group(1)
                impact_metrics.append({
                    "metric": match.group(0),
                    "value": value,
                    "type": "quantifiable"
                })
        
        # Score based on number of metrics found
        if len(impact_metrics) >= 5:
            score += 0.4
        elif len(impact_metrics) >= 3:
            score += 0.3
        elif len(impact_metrics) >= 1:
            score += 0.2
        
        # Look for achievement language
        achievement_keywords = ["achieved", "delivered", "accomplished", "exceeded", "surpassed"]
        achievement_count = sum(1 for keyword in achievement_keywords if keyword in all_text.lower())
        
        if achievement_count >= 3:
            score += 0.2
        elif achievement_count >= 1:
            score += 0.1
        
        # Check for scale indicators (team size, project size)
        scale_indicators = ["team of", "managed", "led", "scaled", "millions", "thousands"]
        scale_count = sum(1 for indicator in scale_indicators if indicator in all_text.lower())
        
        if scale_count >= 2:
            score += 0.2
        
        return {
            "score": min(score, 1.0),
            "metrics_found": len(impact_metrics),
            "metrics": impact_metrics[:10],  # Limit to top 10
            "has_quantifiable_results": len(impact_metrics) > 0
        }
    
    def _analyze_transferable_potential(self, candidate: Dict, job: Dict) -> Dict:
        """
        Analyze transferable skills and learning potential
        Human recruiters look for: ability to adapt, learn new technologies, transfer domain knowledge
        """
        candidate_skills = candidate.get("skills", [])
        job_skills = job.get("required_skills", [])
        
        transferable_signals = []
        score = 0.0
        
        # Use skill ontology to find transferable matches
        skill_analysis = self.semantic_analyzer.analyze_candidate_skills(candidate_skills, job_skills)
        
        # Count transferable matches (not exact matches)
        transferable_matches = [
            match for match in skill_analysis.get("matched_skills", [])
            if match.get("match_type") in ["transferable", "related"]
        ]
        
        if len(transferable_matches) >= 3:
            transferable_signals.append(f"Strong transferable skill potential ({len(transferable_matches)} matches)")
            score += 0.3
        elif len(transferable_matches) >= 1:
            transferable_signals.append(f"Some transferable skills ({len(transferable_matches)} matches)")
            score += 0.15
        
        # Check for learning indicators (certifications, courses, projects)
        certifications = candidate.get("certifications", [])
        if certifications:
            transferable_signals.append("Shows commitment to learning (certifications)")
            score += 0.2
        
        # Check for diverse project experience (indicates adaptability)
        projects = candidate.get("projects", [])
        if len(projects) >= 3:
            transferable_signals.append("Diverse project experience shows adaptability")
            score += 0.15
        
        # Check for career changes or domain switches (shows transferability)
        experience = candidate.get("experience", [])
        if len(experience) >= 2:
            # Simple heuristic: different companies might mean different domains
            companies = [exp.get("company", "") for exp in experience]
            if len(set(companies)) >= 2:
                transferable_signals.append("Experience across different contexts")
                score += 0.1
        
        return {
            "score": min(score, 1.0),
            "transferable_matches": len(transferable_matches),
            "indicators": transferable_signals
        }
    
    def _analyze_contextual_skills(self, candidate: Dict, job: Dict) -> Dict:
        """
        Analyze how skills are applied in context, not just listed
        Human recruiters look for: real-world application, depth of usage
        """
        candidate_skills = candidate.get("skills", [])
        experience = candidate.get("experience", [])
        projects = candidate.get("projects", [])
        job_responsibilities = job.get("responsibilities", [])
        
        contextual_evidence = []
        score = 0.0
        
        # Check if skills are mentioned in context (experience/projects), not just listed
        all_context = " ".join([
            exp.get("description", "") for exp in experience
        ] + [proj.get("description", "") for proj in projects]).lower()
        
        skills_in_context = []
        for skill in candidate_skills:
            skill_lower = skill.lower()
            if skill_lower in all_context:
                skills_in_context.append(skill)
        
        if len(skills_in_context) >= len(candidate_skills) * 0.5:  # At least 50% of skills in context
            contextual_evidence.append(f"Most skills demonstrated in context ({len(skills_in_context)}/{len(candidate_skills)})")
            score += 0.3
        elif len(skills_in_context) > 0:
            contextual_evidence.append(f"Some skills demonstrated in context ({len(skills_in_context)})")
            score += 0.15
        
        # Semantic analysis: how well do skill applications match job context?
        if job_responsibilities:
            job_context = " ".join(job_responsibilities)
            candidate_context = all_context[:1000]  # Limit length
            
            if candidate_context:
                similarity = self.semantic_analyzer.compute_similarity(
                    candidate_context,
                    job_context[:1000]
                )
                if similarity > 0.6:
                    contextual_evidence.append("Skill application context aligns with job requirements")
                    score += 0.3
                elif similarity > 0.4:
                    contextual_evidence.append("Moderate alignment in skill application context")
                    score += 0.15
        
        return {
            "score": min(score, 1.0),
            "skills_in_context": len(skills_in_context),
            "total_skills": len(candidate_skills),
            "indicators": contextual_evidence
        }
    
    def _analyze_learning_potential(self, candidate: Dict) -> Dict:
        """
        Analyze signals of continuous learning and growth mindset
        Human recruiters value: certifications, side projects, self-learning
        """
        learning_signals = []
        score = 0.0
        
        # Certifications
        certifications = candidate.get("certifications", [])
        if certifications:
            learning_signals.append(f"Active learner ({len(certifications)} certifications)")
            score += 0.3
        
        # Side projects
        projects = candidate.get("projects", [])
        if len(projects) >= 3:
            learning_signals.append("Multiple projects show initiative and learning")
            score += 0.2
        
        # Education
        education = candidate.get("education", [])
        if education:
            learning_signals.append("Formal education background")
            score += 0.1
        
        # Check for learning-related keywords
        all_text = candidate.get("raw_text", "").lower()
        learning_keywords = ["learned", "studied", "trained", "certified", "course", "tutorial"]
        learning_mentions = sum(1 for keyword in learning_keywords if keyword in all_text)
        
        if learning_mentions >= 3:
            learning_signals.append("Strong learning mindset indicators")
            score += 0.2
        elif learning_mentions >= 1:
            learning_signals.append("Some learning indicators")
            score += 0.1
        
        return {
            "score": min(score, 1.0),
            "indicators": learning_signals,
            "certifications_count": len(certifications),
            "projects_count": len(projects)
        }
    
    def _analyze_domain_adaptability(self, candidate: Dict, job: Dict) -> Dict:
        """
        Analyze ability to adapt to new domains
        Human recruiters consider: domain experience, transferable domain knowledge
        """
        candidate_domain = self._extract_domain_from_text(candidate.get("raw_text", ""))
        job_domain = job.get("domain", "General")
        
        adaptability_signals = []
        score = 0.0
        
        # Exact domain match
        if candidate_domain == job_domain:
            adaptability_signals.append(f"Domain match: {job_domain}")
            score += 0.4
        elif candidate_domain and job_domain:
            # Check for related domains
            related_domains = {
                "finance": ["fintech", "banking"],
                "healthcare": ["medical", "pharmaceutical"],
                "e-commerce": ["retail", "marketplace"],
                "technology": ["software", "saas"]
            }
            
            if job_domain in related_domains:
                if candidate_domain in related_domains[job_domain]:
                    adaptability_signals.append(f"Related domain experience: {candidate_domain}")
                    score += 0.3
        
        # Check for diverse experience (indicates adaptability)
        experience = candidate.get("experience", [])
        if len(experience) >= 2:
            companies = [exp.get("company", "") for exp in experience]
            if len(set(companies)) >= 2:
                adaptability_signals.append("Experience across different companies/contexts")
                score += 0.2
        
        return {
            "score": min(score, 1.0),
            "candidate_domain": candidate_domain,
            "job_domain": job_domain,
            "indicators": adaptability_signals
        }
    
    def _analyze_experience_depth(self, candidate: Dict, job: Dict) -> Dict:
        """
        Analyze depth vs breadth of experience
        Human recruiters consider: deep expertise vs broad knowledge
        """
        experience = candidate.get("experience", [])
        job_level = job.get("experience_level", "Not specified")
        
        depth_signals = []
        score = 0.0
        
        # Check for seniority indicators
        roles = [exp.get("role", "").lower() for exp in experience]
        senior_roles = sum(1 for role in roles if any(word in role for word in ["senior", "lead", "principal", "architect"]))
        
        if senior_roles >= 1:
            depth_signals.append("Senior-level experience")
            score += 0.3
        
        # Check for long tenure (indicates depth)
        for exp in experience:
            duration = exp.get("duration", "")
            # Simple heuristic: look for years
            if "year" in duration.lower():
                years_match = re.search(r'(\d+)\s*year', duration.lower())
                if years_match:
                    years = int(years_match.group(1))
                    if years >= 3:
                        depth_signals.append(f"Deep experience ({years} years in role)")
                        score += 0.2
                        break
        
        # Check for specialized expertise (mentions of specific technologies deeply)
        all_text = candidate.get("raw_text", "").lower()
        deep_expertise_keywords = ["architected", "designed", "built from scratch", "established", "founded"]
        deep_expertise_count = sum(1 for keyword in deep_expertise_keywords if keyword in all_text)
        
        if deep_expertise_count >= 2:
            depth_signals.append("Deep technical expertise demonstrated")
            score += 0.2
        
        return {
            "score": min(score, 1.0),
            "indicators": depth_signals,
            "senior_roles": senior_roles
        }
    
    def _analyze_communication_signals(self, candidate: Dict) -> Dict:
        """
        Analyze communication and presentation skills
        Human recruiters look for: clear writing, presentation experience, stakeholder communication
        """
        all_text = candidate.get("raw_text", "")
        experience = candidate.get("experience", [])
        
        communication_signals = []
        score = 0.0
        
        # Check for communication-related keywords
        comm_keywords = ["presented", "communicated", "documented", "wrote", "explained", "presentation"]
        comm_count = sum(1 for keyword in comm_keywords if keyword in all_text.lower())
        
        if comm_count >= 3:
            communication_signals.append("Strong communication indicators")
            score += 0.3
        elif comm_count >= 1:
            communication_signals.append("Some communication evidence")
            score += 0.15
        
        # Check for stakeholder interaction
        stakeholder_keywords = ["stakeholders", "clients", "customers", "users", "team"]
        stakeholder_count = sum(1 for keyword in stakeholder_keywords if keyword in all_text.lower())
        
        if stakeholder_count >= 2:
            communication_signals.append("Stakeholder interaction experience")
            score += 0.2
        
        # Check resume quality (clear structure, well-written)
        # Simple heuristic: check for proper sections
        sections = ["experience", "education", "skills", "projects"]
        sections_found = sum(1 for section in sections if section in all_text.lower())
        
        if sections_found >= 3:
            communication_signals.append("Well-structured resume")
            score += 0.1
        
        return {
            "score": min(score, 1.0),
            "indicators": communication_signals,
            "communication_keywords": comm_count
        }
    
    def _analyze_cultural_fit(self, candidate: Dict, job: Dict) -> Dict:
        """
        Analyze cultural fit indicators
        Human recruiters consider: soft skills, collaboration, values alignment
        """
        candidate_soft_skills = candidate.get("soft_skills", [])
        job_soft_skills = job.get("soft_skills", [])
        
        cultural_signals = []
        score = 0.0
        
        # Soft skills match
        if job_soft_skills:
            matches = sum(1 for skill in job_soft_skills 
                        if any(cs.lower() in skill.lower() or skill.lower() in cs.lower() 
                              for cs in candidate_soft_skills))
            if matches >= len(job_soft_skills) * 0.5:
                cultural_signals.append("Strong soft skills alignment")
                score += 0.3
            elif matches > 0:
                cultural_signals.append("Some soft skills match")
                score += 0.15
        
        # Collaboration indicators
        all_text = candidate.get("raw_text", "").lower()
        collaboration_keywords = ["collaborated", "team", "worked with", "cross-functional", "mentored"]
        collab_count = sum(1 for keyword in collaboration_keywords if keyword in all_text)
        
        if collab_count >= 3:
            cultural_signals.append("Strong collaboration indicators")
            score += 0.2
        
        return {
            "score": min(score, 1.0),
            "indicators": cultural_signals
        }
    
    def _extract_domain_from_text(self, text: str) -> Optional[str]:
        """Extract domain/industry from text"""
        text_lower = text.lower()
        
        domains = {
            'finance': ['financial', 'banking', 'fintech', 'investment'],
            'healthcare': ['healthcare', 'medical', 'pharmaceutical', 'health'],
            'e-commerce': ['e-commerce', 'retail', 'shopping', 'marketplace'],
            'education': ['education', 'learning', 'edtech', 'academic'],
            'technology': ['software', 'tech', 'saas', 'platform'],
            'consulting': ['consulting', 'advisory', 'services']
        }
        
        for domain, keywords in domains.items():
            if any(keyword in text_lower for keyword in keywords):
                return domain
        
        return None
    
    def _calculate_human_like_score(self, analysis: Dict) -> float:
        """
        Calculate overall human-like assessment score
        Weighted combination of all human-like factors
        """
        weights = {
            "career_trajectory": 0.15,
            "problem_solving_evidence": 0.20,
            "impact_and_achievements": 0.20,
            "transferable_potential": 0.15,
            "contextual_skill_application": 0.10,
            "learning_potential": 0.10,
            "domain_adaptability": 0.05,
            "experience_depth": 0.03,
            "communication_signals": 0.01,
            "cultural_fit_indicators": 0.01
        }
        
        total_score = 0.0
        for key, weight in weights.items():
            if key in analysis:
                factor_score = analysis[key].get("score", 0.0)
                total_score += factor_score * weight
        
        return min(total_score, 1.0)
    
    def _generate_human_insights(self, analysis: Dict, candidate: Dict, job: Dict) -> List[str]:
        """Generate human-readable insights"""
        insights = []
        
        # Career trajectory
        if analysis["career_trajectory"]["score"] > 0.6:
            insights.append("📈 Shows strong career progression with increasing responsibility")
        
        # Problem solving
        if analysis["problem_solving_evidence"]["score"] > 0.6:
            insights.append("🔧 Demonstrates strong problem-solving approach aligned with job needs")
        
        # Impact
        if analysis["impact_and_achievements"]["has_quantifiable_results"]:
            insights.append(f"📊 Has {analysis['impact_and_achievements']['metrics_found']} quantifiable achievements")
        
        # Transferable potential
        if analysis["transferable_potential"]["score"] > 0.5:
            insights.append("🔄 Shows strong potential to transfer skills to this role")
        
        # Learning
        if analysis["learning_potential"]["score"] > 0.5:
            insights.append("📚 Demonstrates commitment to continuous learning")
        
        return insights

