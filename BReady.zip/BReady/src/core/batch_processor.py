"""
Batch Processing Module - For Hundreds of Resumes
Handles bulk operations efficiently
"""
from typing import List, Dict, Callable
from tqdm import tqdm
import multiprocessing as mp
from functools import partial


class BatchProcessor:
    """
    Batch processor for handling hundreds of resumes efficiently
    - Parallel processing
    - Progress tracking
    - Error handling
    - Memory optimization
    """
    
    def __init__(self, max_workers: int = None):
        """
        Initialize batch processor
        
        Args:
            max_workers: Max parallel workers (default: CPU count)
        """
        self.max_workers = max_workers or min(mp.cpu_count(), 4)  # Limit to 4 for stability
    
    def process_batch(self, items: List, processor_func: Callable, 
                     batch_size: int = 10, show_progress: bool = True) -> List:
        """
        Process items in batches with progress tracking
        
        Args:
            items: List of items to process
            processor_func: Function to process each item
            batch_size: Number of items per batch
            show_progress: Show progress bar
        
        Returns:
            List of processed results
        """
        results = []
        total = len(items)
        
        if show_progress:
            pbar = tqdm(total=total, desc="Processing", unit="item")
        
        for i in range(0, total, batch_size):
            batch = items[i:i + batch_size]
            batch_results = []
            
            for item in batch:
                try:
                    result = processor_func(item)
                    batch_results.append(result)
                except Exception as e:
                    print(f"Error processing item: {e}")
                    batch_results.append(None)
            
            results.extend(batch_results)
            
            if show_progress:
                pbar.update(len(batch))
        
        if show_progress:
            pbar.close()
        
        return results
    
    def process_parallel(self, items: List, processor_func: Callable,
                        show_progress: bool = True) -> List:
        """
        Process items in parallel (for CPU-intensive tasks)
        
        Args:
            items: List of items to process
            processor_func: Function to process each item
            show_progress: Show progress bar
        
        Returns:
            List of processed results
        """
        if not items:
            return []
        
        with mp.Pool(processes=self.max_workers) as pool:
            if show_progress:
                results = list(tqdm(
                    pool.imap(processor_func, items),
                    total=len(items),
                    desc="Processing",
                    unit="item"
                ))
            else:
                results = pool.map(processor_func, items)
        
        return results
    
    def batch_embed(self, texts: List[str], embed_func: Callable,
                   batch_size: int = 32) -> List:
        """
        Batch create embeddings (optimized for large datasets)
        
        Args:
            texts: List of texts to embed
            embed_func: Embedding function
            batch_size: Batch size for embedding
        
        Returns:
            List of embeddings
        """
        embeddings = []
        total = len(texts)
        
        for i in range(0, total, batch_size):
            batch = texts[i:i + batch_size]
            batch_embeddings = embed_func(batch)
            embeddings.extend(batch_embeddings)
        
        return embeddings
    
    def chunk_list(self, items: List, chunk_size: int) -> List[List]:
        """
        Split list into chunks
        
        Args:
            items: List to chunk
            chunk_size: Size of each chunk
        
        Returns:
            List of chunks
        """
        return [items[i:i + chunk_size] for i in range(0, len(items), chunk_size)]

