"""
Job Description Parser Module - Production Version
Extracts structured requirements from job descriptions
"""
import re
import spacy
from typing import Dict, List, Optional


class JobParser:
    """Parse job descriptions and extract requirements"""
    
    def __init__(self):
        try:
            self.nlp = spacy.load("en_core_web_sm")
        except OSError:
            self.nlp = None
    
    def parse_text(self, text: str) -> Dict:
        """Parse job description text and extract structured data"""
        if not self.nlp:
            return self._basic_parse(text)
        
        doc = self.nlp(text)
        
        parsed_data = {
            "title": self._extract_job_title(text),
            "company": self._extract_company(text),
            "required_skills": self._extract_required_skills(doc, text),
            "preferred_skills": self._extract_preferred_skills(text),
            "responsibilities": self._extract_responsibilities(doc, text),
            "requirements": self._extract_requirements(text),
            "experience_level": self._extract_experience_level(text),
            "soft_skills": self._extract_soft_skills(doc, text),
            "domain": self._extract_domain(text),
            "raw_text": text
        }
        
        return parsed_data
    
    def _basic_parse(self, text: str) -> Dict:
        """Basic parsing without spaCy"""
        return {
            "title": self._extract_job_title(text),
            "company": self._extract_company(text),
            "required_skills": self._extract_required_skills_basic(text),
            "preferred_skills": [],
            "responsibilities": [],
            "requirements": [],
            "experience_level": self._extract_experience_level(text),
            "soft_skills": [],
            "domain": self._extract_domain(text),
            "raw_text": text
        }
    
    def _extract_job_title(self, text: str) -> Optional[str]:
        """Extract job title"""
        lines = text.split('\n')[:10]
        for line in lines:
            line = line.strip()
            if any(keyword in line.lower() for keyword in ['developer', 'engineer', 'analyst', 'manager', 'specialist', 'architect']):
                return line
        return "Unknown Position"
    
    def _extract_company(self, text: str) -> Optional[str]:
        """Extract company name"""
        lines = text.split('\n')[:5]
        for line in lines:
            line = line.strip()
            if len(line) > 0 and len(line) < 50:
                if not any(keyword in line.lower() for keyword in ['job', 'position', 'role', 'description', 'requirements']):
                    return line
        return None
    
    def _extract_required_skills(self, doc, text: str) -> List[str]:
        """Extract required technical skills"""
        skills = []
        
        skill_keywords = [
            'python', 'java', 'javascript', 'typescript', 'react', 'angular', 'vue',
            'node.js', 'django', 'flask', 'spring', 'express', 'sql', 'mongodb',
            'postgresql', 'aws', 'azure', 'docker', 'kubernetes', 'git', 'linux',
            'machine learning', 'deep learning', 'tensorflow', 'pytorch', 'scikit-learn',
            'html', 'css', 'bootstrap', 'sass', 'redux', 'graphql', 'rest api',
            'agile', 'scrum', 'ci/cd', 'jenkins', 'terraform', 'ansible'
        ]
        
        text_lower = text.lower()
        
        required_patterns = [
            r'(?:required skills?|must have|requirements?)[:]\s*(.+?)(?:\n\n|\n(?:preferred|nice to have|bonus)|$)',
            r'(?:skills? required|technical requirements?)[:]\s*(.+?)(?:\n\n|\n(?:preferred|nice to have)|$)'
        ]
        
        for pattern in required_patterns:
            match = re.search(pattern, text, re.IGNORECASE | re.DOTALL)
            if match:
                skills_text = match.group(1)
                skills_list = re.split(r'[,•\-\n]', skills_text)
                for skill in skills_list:
                    skill = skill.strip()
                    if len(skill) > 2:
                        skills.append(skill)
        
        for skill in skill_keywords:
            if skill in text_lower:
                skills.append(skill.title())
        
        return list(set(skills))
    
    def _extract_required_skills_basic(self, text: str) -> List[str]:
        """Basic required skills extraction"""
        return self._extract_required_skills(None, text)
    
    def _extract_preferred_skills(self, text: str) -> List[str]:
        """Extract preferred/nice-to-have skills"""
        preferred = []
        
        preferred_pattern = r'(?:preferred|nice to have|bonus|plus)[:]\s*(.+?)(?:\n\n|\n(?:responsibilities|requirements|qualifications)|$)'
        match = re.search(preferred_pattern, text, re.IGNORECASE | re.DOTALL)
        
        if match:
            preferred_text = match.group(1)
            skills_list = re.split(r'[,•\-\n]', preferred_text)
            for skill in skills_list:
                skill = skill.strip()
                if len(skill) > 2:
                    preferred.append(skill)
        
        return list(set(preferred))
    
    def _extract_responsibilities(self, doc, text: str) -> List[str]:
        """Extract job responsibilities"""
        responsibilities = []
        
        resp_patterns = [
            r'(?:responsibilities?|duties?|what you\'ll do)[:]\s*(.+?)(?:\n\n|\n(?:requirements?|qualifications?|skills?)|$)',
            r'(?:key responsibilities?)[:]\s*(.+?)(?:\n\n|\n(?:requirements?|qualifications?)|$)'
        ]
        
        for pattern in resp_patterns:
            match = re.search(pattern, text, re.IGNORECASE | re.DOTALL)
            if match:
                resp_text = match.group(1)
                resp_list = re.split(r'[•\-\n](?=\s*[A-Z])', resp_text)
                for resp in resp_list:
                    resp = resp.strip()
                    if len(resp) > 10:
                        responsibilities.append(resp)
                break
        
        return responsibilities
    
    def _extract_requirements(self, text: str) -> List[str]:
        """Extract general requirements"""
        requirements = []
        
        req_pattern = r'(?:requirements?|qualifications?)[:]\s*(.+?)(?:\n\n|\n(?:responsibilities?|benefits?|compensation)|$)'
        match = re.search(req_pattern, text, re.IGNORECASE | re.DOTALL)
        
        if match:
            req_text = match.group(1)
            req_list = re.split(r'[•\-\n](?=\s*[A-Z])', req_text)
            for req in req_list:
                req = req.strip()
                if len(req) > 10:
                    requirements.append(req)
        
        return requirements
    
    def _extract_experience_level(self, text: str) -> Optional[str]:
        """Extract required experience level"""
        text_lower = text.lower()
        
        if any(word in text_lower for word in ['senior', 'sr.', 'lead', 'principal', 'architect']):
            return "Senior"
        elif any(word in text_lower for word in ['junior', 'jr.', 'entry', 'graduate', 'intern']):
            return "Junior"
        elif any(word in text_lower for word in ['mid', 'middle', 'intermediate']):
            return "Mid-level"
        else:
            return "Not specified"
    
    def _extract_soft_skills(self, doc, text: str) -> List[str]:
        """Extract required soft skills"""
        soft_skills_keywords = [
            'leadership', 'communication', 'teamwork', 'collaboration', 'problem-solving',
            'analytical', 'creative', 'adaptable', 'organized', 'detail-oriented',
            'self-motivated', 'proactive', 'mentoring', 'presentation', 'negotiation'
        ]
        
        found_skills = []
        text_lower = text.lower()
        
        for skill in soft_skills_keywords:
            if skill in text_lower:
                found_skills.append(skill.title())
        
        return list(set(found_skills))
    
    def _extract_domain(self, text: str) -> Optional[str]:
        """Extract industry/domain"""
        domains = {
            'finance': ['financial', 'banking', 'fintech', 'investment'],
            'healthcare': ['healthcare', 'medical', 'pharmaceutical', 'health'],
            'e-commerce': ['e-commerce', 'retail', 'shopping', 'marketplace'],
            'education': ['education', 'learning', 'edtech', 'academic'],
            'technology': ['software', 'tech', 'saas', 'platform'],
            'consulting': ['consulting', 'advisory', 'services']
        }
        
        text_lower = text.lower()
        for domain, keywords in domains.items():
            if any(keyword in text_lower for keyword in keywords):
                return domain
        
        return "General"
