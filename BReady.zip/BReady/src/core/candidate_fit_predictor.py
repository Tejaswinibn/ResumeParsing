"""
Candidate Fit Predictor - Like Lilyhire.com
Predicts how well candidates match job requirements
Uses our unique human-like analysis + semantic matching
"""
from typing import Dict, List
from src.core.human_ranking_engine import HumanRankingEngine
from src.core.semantic_analyzer import SemanticAnalyzer


class CandidateFitPredictor:
    """
    Predicts candidate fit for job roles
    Similar to Lilyhire.com's fit prediction, but with our human-like analysis
    """
    
    def __init__(self):
        self.human_ranking_engine = HumanRankingEngine()
        self.semantic_analyzer = SemanticAnalyzer()
    
    def predict_fit(self, candidate: Dict, job: Dict) -> Dict:
        """
        Predict candidate fit for job
        
        Returns comprehensive fit analysis including:
        - Overall fit score
        - Human-like analysis scores
        - Skill match details
        - Fit explanation
        """
        # Get human-like score breakdown
        score_data = self.human_ranking_engine.calculate_score(candidate, job)
        
        # Calculate fit category
        fit_category = self._categorize_fit(score_data['total_score'])
        
        # Generate fit explanation
        fit_explanation = self._generate_fit_explanation(candidate, job, score_data)
        
        # Identify strengths and gaps
        strengths = self._identify_strengths(score_data)
        gaps = self._identify_gaps(candidate, job, score_data)
        
        return {
            "overall_fit_score": score_data['total_score'],
            "fit_category": fit_category,
            "fit_explanation": fit_explanation,
            "strengths": strengths,
            "gaps": gaps,
            "recommendation": self._generate_recommendation(score_data['total_score']),
            
            # Detailed scores
            "human_like_scores": {
                "career_trajectory": score_data.get('career_trajectory', 0),
                "problem_solving": score_data.get('problem_solving', 0),
                "impact_achievements": score_data.get('impact_achievements', 0),
                "transferable_potential": score_data.get('transferable_potential', 0),
                "learning_potential": score_data.get('learning_potential', 0)
            },
            "traditional_scores": {
                "skill_similarity": score_data.get('skill_similarity', 0),
                "experience_relevance": score_data.get('experience_relevance', 0),
                "project_similarity": score_data.get('project_similarity', 0)
            },
            "detailed_analysis": score_data
        }
    
    def _categorize_fit(self, score: float) -> str:
        """Categorize fit based on score"""
        if score >= 0.8:
            return "Excellent Fit"
        elif score >= 0.65:
            return "Strong Fit"
        elif score >= 0.5:
            return "Moderate Fit"
        elif score >= 0.35:
            return "Weak Fit"
        else:
            return "Poor Fit"
    
    def _generate_fit_explanation(self, candidate: Dict, job: Dict, score_data: Dict) -> str:
        """Generate human-readable fit explanation"""
        score = score_data['total_score']
        name = candidate.get('name', 'Candidate')
        
        if score >= 0.8:
            return f"{name} is an excellent fit for this role. They demonstrate strong alignment across skills, experience, and potential."
        elif score >= 0.65:
            return f"{name} is a strong fit for this role. They have relevant experience and show good potential, with minor gaps that can be addressed."
        elif score >= 0.5:
            return f"{name} is a moderate fit. They have some relevant skills and experience, but there are notable gaps that should be considered."
        elif score >= 0.35:
            return f"{name} is a weak fit. While they may have some transferable skills, significant gaps exist in required qualifications."
        else:
            return f"{name} is not a good fit for this role. The candidate lacks most required qualifications."
    
    def _identify_strengths(self, score_data: Dict) -> List[str]:
        """Identify candidate strengths"""
        strengths = []
        
        if score_data.get('career_trajectory', 0) > 0.7:
            strengths.append("Strong career progression showing growth potential")
        
        if score_data.get('problem_solving', 0) > 0.7:
            strengths.append("Demonstrates strong problem-solving approach")
        
        if score_data.get('impact_achievements', 0) > 0.6:
            strengths.append("Has quantifiable achievements and impact")
        
        if score_data.get('transferable_potential', 0) > 0.6:
            strengths.append("Shows strong potential to transfer skills")
        
        if score_data.get('skill_similarity', 0) > 0.7:
            strengths.append("Strong skill alignment with job requirements")
        
        if score_data.get('learning_potential', 0) > 0.6:
            strengths.append("Demonstrates commitment to continuous learning")
        
        return strengths if strengths else ["Review detailed analysis for specific strengths"]
    
    def _identify_gaps(self, candidate: Dict, job: Dict, score_data: Dict) -> List[str]:
        """Identify gaps between candidate and job requirements"""
        gaps = []
        
        # Skill gaps
        skill_analysis = score_data.get('skill_analysis', {})
        missing_skills = skill_analysis.get('missing_skills', [])
        if missing_skills:
            gaps.append(f"Missing skills: {', '.join(missing_skills[:5])}")
        
        # Experience gaps
        if score_data.get('experience_relevance', 0) < 0.5:
            gaps.append("Limited relevant experience for this role")
        
        # Problem-solving gaps
        if score_data.get('problem_solving', 0) < 0.4:
            gaps.append("Limited evidence of problem-solving approach")
        
        # Impact gaps
        if score_data.get('impact_achievements', 0) < 0.3:
            gaps.append("Limited quantifiable achievements or impact")
        
        # Career trajectory gaps
        if score_data.get('career_trajectory', 0) < 0.4:
            gaps.append("Unclear career progression or limited growth trajectory")
        
        return gaps if gaps else ["No significant gaps identified"]
    
    def _generate_recommendation(self, score: float) -> str:
        """Generate recommendation based on fit score"""
        if score >= 0.8:
            return "Strongly recommend - proceed to interview"
        elif score >= 0.65:
            return "Recommend - good fit, proceed with screening"
        elif score >= 0.5:
            return "Consider - moderate fit, review gaps carefully"
        elif score >= 0.35:
            return "Weak fit - only consider if other factors are strong"
        else:
            return "Not recommended - significant gaps in qualifications"
    
    def batch_predict_fit(self, candidates: List[Dict], job: Dict) -> List[Dict]:
        """Predict fit for multiple candidates"""
        results = []
        for candidate in candidates:
            fit_prediction = self.predict_fit(candidate, job)
            results.append({
                "candidate": candidate,
                "fit_prediction": fit_prediction
            })
        
        # Sort by fit score
        results.sort(key=lambda x: x['fit_prediction']['overall_fit_score'], reverse=True)
        return results

