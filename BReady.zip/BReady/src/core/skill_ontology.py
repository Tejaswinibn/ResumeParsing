"""
Skill Ontology Module
Maps related skills and understands transferability between technologies
"""
from typing import Dict, List, Set
import json


class SkillOntology:
    """Skill ontology for understanding skill relationships and transferability"""
    
    def __init__(self):
        """Initialize skill ontology with predefined skill relationships"""
        self.skill_groups = self._build_skill_groups()
        self.skill_aliases = self._build_skill_aliases()
        self.transferable_skills = self._build_transferable_skills()
    
    def _build_skill_groups(self) -> Dict[str, List[str]]:
        """Build skill groups - skills that are related or similar"""
        return {
            "programming_languages": {
                "python", "java", "javascript", "typescript", "c++", "c#", "go", "rust", "ruby", "php", "swift", "kotlin"
            },
            "web_frontend": {
                "react", "angular", "vue", "html", "css", "javascript", "typescript", "sass", "bootstrap", "tailwind"
            },
            "web_backend": {
                "node.js", "django", "flask", "express", "spring", "fastapi", "rails", "laravel", "asp.net"
            },
            "databases": {
                "postgresql", "mysql", "mongodb", "redis", "sqlite", "oracle", "sql server", "cassandra", "dynamodb"
            },
            "cloud_platforms": {
                "aws", "azure", "gcp", "google cloud", "heroku", "digitalocean", "cloudflare"
            },
            "devops_tools": {
                "docker", "kubernetes", "jenkins", "gitlab ci", "github actions", "terraform", "ansible", "chef", "puppet"
            },
            "ml_ai": {
                "machine learning", "deep learning", "tensorflow", "pytorch", "scikit-learn", "keras", "neural networks"
            },
            "mobile": {
                "react native", "flutter", "ios", "android", "swift", "kotlin", "xamarin"
            }
        }
    
    def _build_skill_aliases(self) -> Dict[str, str]:
        """Build skill aliases - different names for the same skill"""
        return {
            "nodejs": "node.js",
            "node": "node.js",
            "js": "javascript",
            "ts": "typescript",
            "postgres": "postgresql",
            "gcp": "google cloud",
            "gcp": "google cloud platform",
            "ml": "machine learning",
            "dl": "deep learning",
            "ai": "artificial intelligence"
        }
    
    def _build_transferable_skills(self) -> Dict[str, List[str]]:
        """Build transferable skills - skills that indicate ability to learn related skills"""
        return {
            "python": ["django", "flask", "fastapi", "machine learning", "data science"],
            "javascript": ["node.js", "react", "vue", "angular", "typescript"],
            "react": ["vue", "angular", "react native"],
            "django": ["flask", "fastapi", "rails"],
            "postgresql": ["mysql", "sql server", "oracle"],
            "aws": ["azure", "gcp", "google cloud"],
            "docker": ["kubernetes", "containers"],
            "tensorflow": ["pytorch", "keras", "scikit-learn"]
        }
    
    def normalize_skill(self, skill: str) -> str:
        """Normalize skill name (handle aliases and case)"""
        skill_lower = skill.lower().strip()
        
        # Check aliases
        if skill_lower in self.skill_aliases:
            return self.skill_aliases[skill_lower]
        
        return skill_lower
    
    def get_skill_group(self, skill: str) -> str:
        """Get the skill group for a given skill"""
        normalized = self.normalize_skill(skill)
        
        for group_name, skills in self.skill_groups.items():
            if normalized in skills:
                return group_name
        
        return "other"
    
    def are_skills_related(self, skill1: str, skill2: str) -> bool:
        """Check if two skills are related (same group or transferable)"""
        norm1 = self.normalize_skill(skill1)
        norm2 = self.normalize_skill(skill2)
        
        if norm1 == norm2:
            return True
        
        # Check if in same group
        group1 = self.get_skill_group(norm1)
        group2 = self.get_skill_group(norm2)
        if group1 != "other" and group1 == group2:
            return True
        
        # Check transferability
        if norm1 in self.transferable_skills:
            if norm2 in self.transferable_skills[norm1]:
                return True
        
        if norm2 in self.transferable_skills:
            if norm1 in self.transferable_skills[norm2]:
                return True
        
        return False
    
    def get_transferable_skills(self, skill: str) -> List[str]:
        """Get list of skills that are transferable from a given skill"""
        normalized = self.normalize_skill(skill)
        return self.transferable_skills.get(normalized, [])
    
    def enhance_skill_matching(self, candidate_skills: List[str], job_skills: List[str]) -> Dict:
        """Enhance skill matching using ontology"""
        enhanced_matches = []
        missing_skills = []
        
        for job_skill in job_skills:
            job_skill_norm = self.normalize_skill(job_skill)
            matched = False
            
            # Direct match
            for cand_skill in candidate_skills:
                cand_skill_norm = self.normalize_skill(cand_skill)
                if cand_skill_norm == job_skill_norm:
                    enhanced_matches.append({
                        "job_skill": job_skill,
                        "candidate_skill": cand_skill,
                        "match_type": "exact",
                        "confidence": 1.0
                    })
                    matched = True
                    break
            
            # Related/transferable match
            if not matched:
                for cand_skill in candidate_skills:
                    if self.are_skills_related(cand_skill, job_skill):
                        enhanced_matches.append({
                            "job_skill": job_skill,
                            "candidate_skill": cand_skill,
                            "match_type": "transferable",
                            "confidence": 0.7
                        })
                        matched = True
                        break
            
            if not matched:
                missing_skills.append(job_skill)
        
        return {
            "enhanced_matches": enhanced_matches,
            "missing_skills": missing_skills,
            "match_count": len(enhanced_matches),
            "total_job_skills": len(job_skills)
        }


