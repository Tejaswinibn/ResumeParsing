"""
Job Posting Analyzer - Like Lilyhire.com
Analyzes and optimizes job postings to attract better candidates
"""
from typing import Dict, List
from src.core.semantic_analyzer import SemanticAnalyzer
from src.core.job_parser import JobParser


class JobPostingAnalyzer:
    """
    Analyzes job postings and provides optimization suggestions
    Similar to Lilyhire.com's job posting optimization
    """
    
    def __init__(self):
        self.job_parser = JobParser()
        self.semantic_analyzer = SemanticAnalyzer()
    
    def analyze_job_posting(self, job_text: str) -> Dict:
        """
        Analyze job posting and provide insights
        
        Returns:
            - Clarity score
            - Missing information
            - Optimization suggestions
            - Attractiveness score
        """
        parsed_job = self.job_parser.parse_text(job_text)
        
        analysis = {
            "clarity_score": self._calculate_clarity_score(job_text, parsed_job),
            "completeness_score": self._calculate_completeness_score(parsed_job),
            "attractiveness_score": self._calculate_attractiveness_score(job_text, parsed_job),
            "missing_information": self._identify_missing_information(parsed_job),
            "optimization_suggestions": self._generate_suggestions(job_text, parsed_job),
            "skill_coverage": self._analyze_skill_coverage(parsed_job),
            "requirements_clarity": self._analyze_requirements_clarity(parsed_job)
        }
        
        return analysis
    
    def _calculate_clarity_score(self, job_text: str, parsed_job: Dict) -> float:
        """Calculate how clear the job posting is"""
        score = 1.0
        
        # Check for vague terms
        vague_terms = ["etc", "and more", "various", "multiple", "some"]
        vague_count = sum(1 for term in vague_terms if term in job_text.lower())
        if vague_count > 3:
            score -= 0.2
        
        # Check for specific details
        specific_indicators = ["years", "experience", "required", "preferred", "skills"]
        specific_count = sum(1 for indicator in specific_indicators if indicator in job_text.lower())
        if specific_count >= 5:
            score += 0.1
        
        # Check structure
        has_title = bool(parsed_job.get('title') and parsed_job['title'] != 'Unknown Position')
        has_skills = len(parsed_job.get('required_skills', [])) > 0
        has_responsibilities = len(parsed_job.get('responsibilities', [])) > 0
        
        if not has_title:
            score -= 0.3
        if not has_skills:
            score -= 0.2
        if not has_responsibilities:
            score -= 0.2
        
        return max(0.0, min(1.0, score))
    
    def _calculate_completeness_score(self, parsed_job: Dict) -> float:
        """Calculate how complete the job posting is"""
        score = 0.0
        max_score = 10.0
        
        # Title
        if parsed_job.get('title') and parsed_job['title'] != 'Unknown Position':
            score += 1.0
        
        # Company
        if parsed_job.get('company'):
            score += 1.0
        
        # Required skills
        if len(parsed_job.get('required_skills', [])) > 0:
            score += 2.0
        
        # Preferred skills
        if len(parsed_job.get('preferred_skills', [])) > 0:
            score += 1.0
        
        # Responsibilities
        if len(parsed_job.get('responsibilities', [])) > 0:
            score += 2.0
        
        # Requirements
        if len(parsed_job.get('requirements', [])) > 0:
            score += 1.0
        
        # Experience level
        if parsed_job.get('experience_level') and parsed_job['experience_level'] != 'Not specified':
            score += 1.0
        
        # Domain
        if parsed_job.get('domain') and parsed_job['domain'] != 'General':
            score += 1.0
        
        return score / max_score
    
    def _calculate_attractiveness_score(self, job_text: str, parsed_job: Dict) -> float:
        """Calculate how attractive the job posting is to candidates"""
        score = 0.5  # Base score
        
        # Positive keywords
        positive_keywords = [
            "competitive salary", "benefits", "remote", "flexible",
            "growth", "opportunity", "innovative", "cutting-edge",
            "collaborative", "team", "impact", "challenge"
        ]
        positive_count = sum(1 for keyword in positive_keywords if keyword in job_text.lower())
        score += min(0.3, positive_count * 0.05)
        
        # Negative keywords (reduce score)
        negative_keywords = [
            "must", "required", "mandatory", "strict", "only"
        ]
        negative_count = sum(1 for keyword in negative_keywords if keyword in job_text.lower())
        score -= min(0.2, negative_count * 0.03)
        
        # Remote work mention
        if any(word in job_text.lower() for word in ["remote", "work from home", "wfh", "hybrid"]):
            score += 0.1
        
        # Salary/compensation mention
        if any(word in job_text.lower() for word in ["salary", "compensation", "pay", "$"]):
            score += 0.1
        
        return max(0.0, min(1.0, score))
    
    def _identify_missing_information(self, parsed_job: Dict) -> List[str]:
        """Identify missing information in job posting"""
        missing = []
        
        if not parsed_job.get('title') or parsed_job['title'] == 'Unknown Position':
            missing.append("Job title is unclear or missing")
        
        if not parsed_job.get('company'):
            missing.append("Company name is missing")
        
        if len(parsed_job.get('required_skills', [])) == 0:
            missing.append("Required skills are not specified")
        
        if len(parsed_job.get('responsibilities', [])) == 0:
            missing.append("Job responsibilities are not detailed")
        
        if parsed_job.get('experience_level') == 'Not specified':
            missing.append("Experience level is not specified")
        
        if not any(word in parsed_job.get('raw_text', '').lower() for word in ["salary", "compensation", "pay"]):
            missing.append("Salary/compensation information is missing")
        
        if not any(word in parsed_job.get('raw_text', '').lower() for word in ["remote", "location", "office"]):
            missing.append("Location/work arrangement is not specified")
        
        return missing
    
    def _generate_suggestions(self, job_text: str, parsed_job: Dict) -> List[str]:
        """Generate optimization suggestions"""
        suggestions = []
        
        # Skill suggestions
        if len(parsed_job.get('required_skills', [])) < 5:
            suggestions.append("Add more specific required skills (aim for 5-8 skills)")
        
        # Responsibilities suggestions
        if len(parsed_job.get('responsibilities', [])) < 3:
            suggestions.append("Add more detailed job responsibilities (aim for 5-7 bullet points)")
        
        # Clarity suggestions
        if len(job_text.split()) < 200:
            suggestions.append("Expand job description for better clarity (aim for 300-500 words)")
        
        # Attractiveness suggestions
        if not any(word in job_text.lower() for word in ["benefits", "perks", "culture"]):
            suggestions.append("Add information about company culture, benefits, or perks")
        
        # Remote work suggestion
        if not any(word in job_text.lower() for word in ["remote", "hybrid", "location"]):
            suggestions.append("Specify work arrangement (remote, hybrid, or on-site)")
        
        # Experience level suggestion
        if parsed_job.get('experience_level') == 'Not specified':
            suggestions.append("Specify required experience level (Junior, Mid-level, Senior)")
        
        return suggestions
    
    def _analyze_skill_coverage(self, parsed_job: Dict) -> Dict:
        """Analyze skill coverage in job posting"""
        required_skills = parsed_job.get('required_skills', [])
        preferred_skills = parsed_job.get('preferred_skills', [])
        
        return {
            "required_skills_count": len(required_skills),
            "preferred_skills_count": len(preferred_skills),
            "total_skills_count": len(required_skills) + len(preferred_skills),
            "recommended_range": "5-8 required skills, 3-5 preferred skills",
            "is_balanced": 5 <= len(required_skills) <= 10 and len(preferred_skills) >= 0
        }
    
    def _analyze_requirements_clarity(self, parsed_job: Dict) -> Dict:
        """Analyze clarity of requirements"""
        requirements = parsed_job.get('requirements', [])
        responsibilities = parsed_job.get('responsibilities', [])
        
        return {
            "requirements_count": len(requirements),
            "responsibilities_count": len(responsibilities),
            "has_clear_structure": len(requirements) > 0 and len(responsibilities) > 0,
            "recommendation": "Separate 'Requirements' from 'Responsibilities' for better clarity"
        }

