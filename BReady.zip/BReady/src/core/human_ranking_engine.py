"""
Human-Like Ranking Engine
Combines traditional scoring with human-like holistic analysis
Mimics how human recruiters actually think about candidates
"""
import sys
import os
from typing import List, Dict, Optional

# Add project root to path
project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, project_root)

import config
from src.core.semantic_analyzer import SemanticAnalyzer
from src.core.human_analyzer import HumanAnalyzer
from src.core.interfaces import IRankingStrategy


class HumanRankingEngine(IRankingStrategy):
    """
    Human-like ranking that goes beyond keyword matching
    
    Combines:
    1. Traditional semantic matching (skills, experience, projects)
    2. Human-like holistic analysis (career trajectory, problem-solving, potential)
    
    This mimics how experienced recruiters actually evaluate candidates
    """
    
    def __init__(self, semantic_analyzer: Optional[SemanticAnalyzer] = None, 
                 human_analyzer: Optional[HumanAnalyzer] = None,
                 weights: Optional[Dict] = None):
        """
        Initialize human-like ranking engine
        
        Args:
            semantic_analyzer: For semantic matching
            human_analyzer: For human-like analysis
            weights: Custom weights (uses config if None)
        """
        self.semantic_analyzer = semantic_analyzer or SemanticAnalyzer()
        self.human_analyzer = human_analyzer or HumanAnalyzer(self.semantic_analyzer)
        
        # Human-like ranking weights (different from traditional)
        self.weights = weights or {
            # Traditional factors (40% total)
            "skill_similarity": 0.15,  # Reduced from 0.35
            "experience_relevance": 0.15,  # Reduced from 0.30
            "project_similarity": 0.10,  # Reduced from 0.20
            
            # Human-like factors (60% total) - THIS IS THE UNIQUE PART
            "career_trajectory": 0.15,
            "problem_solving": 0.15,
            "impact_achievements": 0.10,
            "transferable_potential": 0.10,
            "contextual_skills": 0.05,
            "learning_potential": 0.05,
            "domain_adaptability": 0.03,
            "experience_depth": 0.02,
            
            # Supporting factors
            "education_certifications": 0.05,
            "soft_skills": 0.03,
            "communication": 0.02
        }
    
    def rank_candidates(self, candidates: List[Dict], job_description: Dict) -> List[Dict]:
        """Rank candidates using human-like analysis"""
        ranked_candidates = []
        
        for candidate in candidates:
            score_data = self._calculate_human_like_score(candidate, job_description)
            ranked_candidates.append({
                "candidate": candidate,
                "score": score_data["total_score"],
                "score_breakdown": score_data,
                "human_insights": score_data.get("human_insights", [])
            })
        
        # Sort by total score (descending)
        ranked_candidates.sort(key=lambda x: x["score"], reverse=True)
        
        return ranked_candidates
    
    def calculate_score(self, candidate: Dict, job: Dict) -> Dict:
        """Calculate human-like ranking score"""
        return self._calculate_human_like_score(candidate, job)
    
    def _calculate_human_like_score(self, candidate: Dict, job: Dict) -> Dict:
        """
        Calculate comprehensive human-like score
        
        This is what makes it unique - goes beyond keywords!
        """
        # Step 1: Traditional semantic analysis (still important)
        skill_analysis = self.semantic_analyzer.analyze_candidate_skills(
            candidate.get("skills", []),
            job.get("required_skills", [])
        )
        
        experience_analysis = self.semantic_analyzer.analyze_experience(
            candidate.get("experience", []),
            job.get("responsibilities", []) + job.get("requirements", [])
        )
        
        project_analysis = self.semantic_analyzer.analyze_projects(
            candidate.get("projects", []),
            job.get("responsibilities", [])
        )
        
        # Step 2: Human-like holistic analysis (THE UNIQUE PART)
        human_analysis = self.human_analyzer.analyze_candidate_holistically(candidate, job)
        
        # Step 3: Supporting factors
        education_score = self._calculate_education_score(candidate, job)
        soft_skills_score = self._calculate_soft_skills_score(
            candidate.get("soft_skills", []),
            job.get("soft_skills", [])
        )
        
        # Step 4: Calculate weighted total score
        total_score = (
            # Traditional factors (40%)
            skill_analysis["similarity_score"] * self.weights["skill_similarity"] +
            experience_analysis["similarity_score"] * self.weights["experience_relevance"] +
            project_analysis["similarity_score"] * self.weights["project_similarity"] +
            
            # Human-like factors (60%) - THIS IS WHAT MAKES IT UNIQUE
            human_analysis["career_trajectory"]["score"] * self.weights["career_trajectory"] +
            human_analysis["problem_solving_evidence"]["score"] * self.weights["problem_solving"] +
            human_analysis["impact_and_achievements"]["score"] * self.weights["impact_achievements"] +
            human_analysis["transferable_potential"]["score"] * self.weights["transferable_potential"] +
            human_analysis["contextual_skill_application"]["score"] * self.weights["contextual_skills"] +
            human_analysis["learning_potential"]["score"] * self.weights["learning_potential"] +
            human_analysis["domain_adaptability"]["score"] * self.weights["domain_adaptability"] +
            human_analysis["experience_depth"]["score"] * self.weights["experience_depth"] +
            
            # Supporting factors
            education_score * self.weights["education_certifications"] +
            soft_skills_score * self.weights["soft_skills"] +
            human_analysis["communication_signals"]["score"] * self.weights["communication"]
        )
        
        return {
            "total_score": total_score,
            
            # Traditional scores
            "skill_similarity": skill_analysis["similarity_score"],
            "experience_relevance": experience_analysis["similarity_score"],
            "project_similarity": project_analysis["similarity_score"],
            
            # Human-like scores (THE UNIQUE PART)
            "career_trajectory": human_analysis["career_trajectory"]["score"],
            "problem_solving": human_analysis["problem_solving_evidence"]["score"],
            "impact_achievements": human_analysis["impact_and_achievements"]["score"],
            "transferable_potential": human_analysis["transferable_potential"]["score"],
            "contextual_skills": human_analysis["contextual_skill_application"]["score"],
            "learning_potential": human_analysis["learning_potential"]["score"],
            "domain_adaptability": human_analysis["domain_adaptability"]["score"],
            "experience_depth": human_analysis["experience_depth"]["score"],
            "communication": human_analysis["communication_signals"]["score"],
            
            # Supporting scores
            "education_certifications": education_score,
            "soft_skills": soft_skills_score,
            
            # Detailed analysis
            "human_analysis": human_analysis,
            "human_insights": human_analysis.get("human_like_insights", []),
            "skill_analysis": skill_analysis,
            "experience_analysis": experience_analysis,
            "project_analysis": project_analysis
        }
    
    def _calculate_education_score(self, candidate: Dict, job: Dict) -> float:
        """Calculate education and certifications score"""
        score = 0.0
        
        certifications = candidate.get("certifications", [])
        if certifications:
            score += 0.3
        
        education = candidate.get("education", [])
        if education:
            score += 0.2
        
        job_text = job.get("raw_text", "").lower()
        if any(keyword in job_text for keyword in ["degree", "bachelor", "master", "phd", "education"]):
            if education:
                score += 0.5
        
        return min(score, 1.0)
    
    def _calculate_soft_skills_score(self, candidate_skills: List[str], job_skills: List[str]) -> float:
        """Calculate soft skills matching score"""
        if not job_skills:
            return 0.5
        
        if not candidate_skills:
            return 0.0
        
        candidate_skills_lower = [s.lower() for s in candidate_skills]
        job_skills_lower = [s.lower() for s in job_skills]
        
        matches = sum(1 for skill in job_skills_lower 
                     if any(cs in skill or skill in cs for cs in candidate_skills_lower))
        
        return matches / len(job_skills) if job_skills else 0.0

