"""
Lilyhire.com-like UI Tabs
Candidate Search, Job Posting, Dashboard
"""
import sys
import os
import streamlit as st
from typing import Dict, List
import pandas as pd

# Add project root to path
project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, project_root)

from src.core import OptimizedCandidateDatabase, JobPostingAnalyzer, CandidateFitPredictor
from src.utils import display_candidate_summary, save_uploaded_file, cleanup_file


def candidate_search_tab(parsers: Dict):
    """Candidate Search Tab - Like Lilyhire.com"""
    st.header("🔍 Candidate Search")
    st.markdown("Search and filter candidates from your database with advanced NLP filters")
    
    db = parsers['candidate_database']
    fit_predictor = parsers['fit_predictor']
    
    # Search and filters
    col1, col2 = st.columns([2, 1])
    
    with col1:
        search_query = st.text_input(
            "🔎 Search candidates",
            placeholder="Enter skills, experience, or keywords...",
            help="Search across name, skills, experience, and education"
        )
    
    with col2:
        st.write("")  # Spacing
        if st.button("🔍 Search", type="primary"):
            # Use pagination for large results
            search_result = db.search_candidates(
                search_query, 
                st.session_state.get('search_filters', {}),
                limit=50,  # Show 50 at a time
                offset=0
            )
            st.session_state.search_results = search_result.get('results', [])
            st.session_state.search_total = search_result.get('total', 0)
    
    # Advanced filters (like Lilyhire.com)
    with st.expander("🔧 Advanced NLP Filters"):
        filter_col1, filter_col2, filter_col3 = st.columns(3)
        
        with filter_col1:
            experience_level = st.selectbox(
                "Experience Level",
                ["All", "Junior", "Mid-level", "Senior"],
                index=0
            )
            
            years_experience = st.number_input(
                "Min Years Experience",
                min_value=0,
                max_value=20,
                value=0
            )
        
        with filter_col2:
            skills_input = st.text_input(
                "Required Skills",
                placeholder="Python, React, AWS (comma-separated)",
                help="Filter by required skills"
            )
            
            location = st.text_input(
                "Location",
                placeholder="City, State, or Remote",
                help="Filter by location"
            )
        
        with filter_col3:
            status = st.selectbox(
                "Status",
                ["All", "active", "shortlisted", "rejected", "hired"],
                index=0
            )
            
            tags_input = st.text_input(
                "Tags",
                placeholder="tag1, tag2 (comma-separated)",
                help="Filter by tags"
            )
        
        # Build filters dict
        filters = {}
        if experience_level != "All":
            filters['experience_level'] = experience_level.lower()
        if years_experience > 0:
            filters['years_experience'] = years_experience
        if skills_input:
            filters['skills'] = [s.strip() for s in skills_input.split(',')]
        if location:
            filters['location'] = location
        if status != "All":
            filters['status'] = status
        if tags_input:
            filters['tags'] = [t.strip() for t in tags_input.split(',')]
        
        st.session_state.search_filters = filters
        
        if st.button("Apply Filters", type="primary"):
            st.session_state.search_results = db.search_candidates(search_query, filters)
    
    # Job selection for fit prediction
    if st.session_state.get('job_description'):
        st.info("💡 Job description loaded. Fit scores will be calculated automatically.")
    
    # Pagination controls
    if 'search_total' in st.session_state and st.session_state.search_total > 50:
        col_p1, col_p2, col_p3 = st.columns([1, 2, 1])
        with col_p2:
            page = st.number_input("Page", min_value=1, max_value=(st.session_state.search_total // 50) + 1, value=1)
            if st.button("Load Page"):
                offset = (page - 1) * 50
                search_result = db.search_candidates(
                    search_query,
                    st.session_state.get('search_filters', {}),
                    limit=50,
                    offset=offset
                )
                st.session_state.search_results = search_result.get('results', [])
                st.rerun()
    
    # Display search results
    if 'search_results' in st.session_state and st.session_state.search_results:
        st.markdown("---")
        total_display = st.session_state.get('search_total', len(st.session_state.search_results))
        st.subheader(f"📋 Found {total_display} candidates (showing {len(st.session_state.search_results)})")
        
        # Fit prediction if job is loaded
        if st.session_state.get('job_description'):
            with st.spinner("Calculating fit scores..."):
                fit_results = fit_predictor.batch_predict_fit(
                    st.session_state.search_results,
                    st.session_state.job_description
                )
                
                # Display with fit scores
                for i, result in enumerate(fit_results):
                    candidate = result['candidate']
                    fit = result['fit_prediction']
                    
                    with st.expander(
                        f"#{i+1} {candidate.get('name', 'Unknown')} - "
                        f"Fit: {fit['fit_category']} ({fit['overall_fit_score']:.1%})"
                    ):
                        col1, col2 = st.columns([2, 1])
                        
                        with col1:
                            display_candidate_summary(candidate, i)
                            
                            # Fit details
                            st.write("**🎯 Fit Analysis:**")
                            st.write(fit['fit_explanation'])
                            
                            if fit['strengths']:
                                st.write("**✅ Strengths:**")
                                for strength in fit['strengths']:
                                    st.write(f"• {strength}")
                            
                            if fit['gaps']:
                                st.write("**⚠️ Gaps:**")
                                for gap in fit['gaps']:
                                    st.write(f"• {gap}")
                        
                        with col2:
                            st.metric("Fit Score", f"{fit['overall_fit_score']:.1%}")
                            st.metric("Category", fit['fit_category'])
                            st.write(f"**Recommendation:** {fit['recommendation']}")
                            
                            # Actions
                            if st.button(f"📌 Shortlist", key=f"shortlist_{i}"):
                                db.update_status(candidate['id'], 'shortlisted')
                                st.success("Added to shortlist!")
                            
                            if st.button(f"❌ Reject", key=f"reject_{i}"):
                                db.update_status(candidate['id'], 'rejected')
                                st.info("Marked as rejected")
        else:
            # Display without fit scores
            for i, candidate in enumerate(st.session_state.search_results):
                with st.expander(f"#{i+1} {candidate.get('name', 'Unknown')}"):
                    display_candidate_summary(candidate, i)
                    
                    col1, col2 = st.columns(2)
                    with col1:
                        if st.button(f"📌 Shortlist", key=f"shortlist_{i}"):
                            db.update_status(candidate['id'], 'shortlisted')
                            st.success("Added to shortlist!")
                    with col2:
                        if st.button(f"❌ Reject", key=f"reject_{i}"):
                            db.update_status(candidate['id'], 'rejected')
                            st.info("Marked as rejected")
    else:
        st.info("👆 Enter a search query and click Search, or use Advanced Filters")


def job_posting_tab(parsers: Dict):
    """Job Posting Tab - Like Lilyhire.com"""
    st.header("📝 Job Posting Analysis & Optimization")
    st.markdown("Analyze and optimize job postings to attract better candidates")
    
    job_analyzer = parsers['job_posting_analyzer']
    job_parser = parsers['job_parser']
    
    # Job posting input
    job_input_method = st.radio(
        "Input method:",
        ["Text Input", "File Upload"],
        horizontal=True
    )
    
    if job_input_method == "Text Input":
        job_text = st.text_area(
            "Paste job description:",
            height=300,
            help="Paste the full job description here"
        )
    else:
        uploaded_file = st.file_uploader("Upload job description file", type=['pdf', 'docx', 'txt'])
        if uploaded_file:
            from src.utils import extract_text_from_file
            tmp_path = save_uploaded_file(uploaded_file)
            job_text = extract_text_from_file(tmp_path)
            cleanup_file(tmp_path)
        else:
            job_text = ""
    
    if st.button("🔍 Analyze Job Posting", type="primary") and job_text:
        with st.spinner("Analyzing job posting..."):
            analysis = job_analyzer.analyze_job_posting(job_text)
            parsed_job = job_parser.parse_text(job_text)
            
            # Store in session state
            st.session_state.job_description = parsed_job
            st.session_state.job_analysis = analysis
            
            st.success("✅ Job posting analyzed!")
    
    # Display analysis
    if 'job_analysis' in st.session_state:
        analysis = st.session_state.job_analysis
        
        st.markdown("---")
        st.subheader("📊 Analysis Results")
        
        # Scores
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Clarity Score", f"{analysis['clarity_score']:.1%}")
        with col2:
            st.metric("Completeness", f"{analysis['completeness_score']:.1%}")
        with col3:
            st.metric("Attractiveness", f"{analysis['attractiveness_score']:.1%}")
        
        # Missing information
        if analysis['missing_information']:
            st.markdown("### ⚠️ Missing Information")
            for missing in analysis['missing_information']:
                st.warning(f"• {missing}")
        
        # Optimization suggestions
        if analysis['optimization_suggestions']:
            st.markdown("### 💡 AI Optimization Suggestions")
            for suggestion in analysis['optimization_suggestions']:
                st.info(f"• {suggestion}")
        
        # Skill coverage
        skill_coverage = analysis['skill_coverage']
        st.markdown("### 📋 Skill Coverage")
        st.write(f"**Required Skills:** {skill_coverage['required_skills_count']}")
        st.write(f"**Preferred Skills:** {skill_coverage['preferred_skills_count']}")
        st.write(f"**Recommendation:** {skill_coverage['recommended_range']}")
        
        if not skill_coverage['is_balanced']:
            st.warning("⚠️ Skill coverage could be improved. See suggestions above.")
        
        # Requirements clarity
        req_clarity = analysis['requirements_clarity']
        st.markdown("### 📝 Requirements Clarity")
        st.write(f"**Requirements:** {req_clarity['requirements_count']}")
        st.write(f"**Responsibilities:** {req_clarity['responsibilities_count']}")
        if req_clarity['has_clear_structure']:
            st.success("✅ Clear structure with separate requirements and responsibilities")
        else:
            st.warning(f"⚠️ {req_clarity['recommendation']}")


def dashboard_tab(parsers: Dict):
    """Dashboard Tab - CRM-like candidate management (Like Lilyhire.com)"""
    st.header("📊 Candidate Dashboard")
    st.markdown("Manage and track candidates - CRM-like interface")
    
    db = parsers['candidate_database']
    
    # Statistics (optimized)
    stats = db.get_statistics()
    
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Total Candidates", stats.get('total_candidates', 0))
    with col2:
        st.metric("Active", stats.get('by_status', {}).get('active', 0))
    with col3:
        st.metric("Shortlisted", stats.get('by_status', {}).get('shortlisted', 0))
    with col4:
        st.metric("Hired", stats.get('by_status', {}).get('hired', 0))
    
    st.markdown("---")
    
    # Filter by status
    status_filter = st.selectbox(
        "Filter by Status",
        ["All", "active", "shortlisted", "rejected", "hired"],
        index=0
    )
    
    # Get candidates with pagination
    if status_filter == "All":
        result = db.get_all_candidates(limit=50, offset=0)
    else:
        result = db.get_candidates_by_status(status_filter, limit=50, offset=0)
    
    display_candidates = result.get('results', [])
    total_candidates = result.get('total', 0)
    
    st.subheader(f"📋 Candidates ({total_candidates} total, showing {len(display_candidates)})")
    
    # Pagination
    if total_candidates > 50:
        page = st.number_input("Page", min_value=1, max_value=(total_candidates // 50) + 1, value=1, key="dashboard_page")
        if st.button("Load Page", key="dashboard_load"):
            offset = (page - 1) * 50
            if status_filter == "All":
                result = db.get_all_candidates(limit=50, offset=offset)
            else:
                result = db.get_candidates_by_status(status_filter, limit=50, offset=offset)
            display_candidates = result.get('results', [])
            st.rerun()
    
    # Display candidates
    for i, candidate in enumerate(display_candidates):
        with st.expander(f"{candidate.get('name', 'Unknown')} - {candidate.get('status', 'active').title()}"):
            col1, col2 = st.columns([2, 1])
            
            with col1:
                display_candidate_summary(candidate, i)
                
                # Notes
                if candidate.get('notes'):
                    st.markdown("**📝 Notes:**")
                    for note in candidate['notes'][-5:]:  # Show last 5
                        st.caption(f"{note.get('author', 'Recruiter')}: {note.get('text', '')}")
                
                # Tags
                if candidate.get('tags'):
                    st.write("**🏷️ Tags:**", ", ".join(candidate['tags']))
            
            with col2:
                # Status update
                new_status = st.selectbox(
                    "Status",
                    ["active", "shortlisted", "rejected", "hired"],
                    index=["active", "shortlisted", "rejected", "hired"].index(candidate.get('status', 'active')),
                    key=f"status_{i}"
                )
                if new_status != candidate.get('status'):
                    db.update_status(candidate['id'], new_status)
                    st.rerun()
                
                # Add note
                note_text = st.text_area("Add note", key=f"note_{i}", height=100)
                if st.button("💾 Save Note", key=f"save_note_{i}") and note_text:
                    db.add_note(candidate['id'], note_text)
                    st.success("Note added!")
                    st.rerun()
                
                # Add tag
                tag_text = st.text_input("Add tag", key=f"tag_{i}")
                if st.button("🏷️ Add Tag", key=f"add_tag_{i}") and tag_text:
                    db.add_tag(candidate['id'], tag_text)
                    st.success("Tag added!")
                    st.rerun()

