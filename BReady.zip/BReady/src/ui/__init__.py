"""
Streamlit UI Application
"""

from .app import main

__all__ = ['main']

