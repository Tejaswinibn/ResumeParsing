"""
Streamlit Web Application for AI Recruitment Assistant
Simplified and restructured for better maintainability
"""
import streamlit as st
from typing import Dict

import sys
import os

# Add project root to path
project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, project_root)

from src.core import (
    ResumeParser, JobParser, RankingEngine, HumanRankingEngine, ReportGenerator,
    OptimizedCandidateDatabase, JobPostingAnalyzer, CandidateFitPredictor
)
from src.utils import render_sidebar, display_candidate_summary, display_ranking_summary, display_candidate_details
from src.utils import extract_text_from_file, save_uploaded_file, cleanup_file
from src.ui.lilyhire_tabs import candidate_search_tab, job_posting_tab, dashboard_tab
import config

# Configure Streamlit secrets (for Streamlit Cloud)
try:
    if hasattr(st, 'secrets'):
        if 'OPENAI_API_KEY' in st.secrets:
            config.OPENAI_API_KEY = st.secrets['OPENAI_API_KEY']
        if 'OPENAI_MODEL' in st.secrets:
            config.OPENAI_MODEL = st.secrets['OPENAI_MODEL']
except (AttributeError, RuntimeError):
    pass

# Page configuration
st.set_page_config(
    page_title="AI Recruitment Assistant",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize session state
def init_session_state():
    """Initialize session state variables"""
    defaults = {
        'candidates': [],
        'job_description': None,
        'ranked_candidates': [],
        'reports': {}
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value

init_session_state()

# Initialize parsers and engines (cached)
@st.cache_resource
def load_parsers():
    """Load parsers and engines (cached for performance)"""
    return {
        'resume_parser': ResumeParser(),
        'job_parser': JobParser(),
        'ranking_engine': HumanRankingEngine(),  # Human-like ranking by default
        'traditional_ranking_engine': RankingEngine(),  # Keep traditional as backup
        'report_generator': ReportGenerator(),
        'candidate_database': OptimizedCandidateDatabase(),  # Optimized for hundreds of resumes
        'job_posting_analyzer': JobPostingAnalyzer(),  # Like Lilyhire.com
        'fit_predictor': CandidateFitPredictor()  # Like Lilyhire.com
    }

parsers = load_parsers()

def main():
    """Main application entry point - Like Lilyhire.com"""
    st.title("🤖 BReady - Recruiter Candidate Sourcing Platform")
    st.markdown("**Like Lilyhire.com** - Source, screen, and manage candidates with AI-powered human-like analysis.")
    
    # Render sidebar
    with st.sidebar:
        render_sidebar()
    
    # Main tabs - Like Lilyhire.com structure
    tab1, tab2, tab3, tab4 = st.tabs([
        "🔍 Candidate Search",  # Like Lilyhire.com
        "📝 Job Posting",       # Like Lilyhire.com
        "📊 Dashboard",        # Like Lilyhire.com (CRM)
        "📄 Upload & Parse"     # Add candidates to database
    ])
    
    with tab1:
        candidate_search_tab(parsers)
    with tab2:
        job_posting_tab(parsers)
    with tab3:
        dashboard_tab(parsers)
    with tab4:
        upload_tab(parsers)

def upload_tab(parsers: Dict):
    """Upload and parse resumes - Add to database (Like Lilyhire.com)"""
    st.header("📄 Upload & Parse Resumes")
    st.markdown("Upload resumes to add candidates to your database")
    
    db = parsers['candidate_database']
    resume_parser = parsers['resume_parser']
    
    # Resume upload section
    st.subheader("📄 Upload Resumes")
    uploaded_resumes = st.file_uploader(
        "Upload resume files (PDF, DOCX, TXT)",
        type=['pdf', 'docx', 'txt'],
        accept_multiple_files=True,
        help="Upload one or more resume files to add to candidate database"
    )
    
    if uploaded_resumes and st.button("📥 Parse & Add to Database", type="primary"):
        parse_and_add_to_database(uploaded_resumes, resume_parser, db)
    
    # Display database stats
    all_candidates = db.get_all_candidates()
    if all_candidates:
        st.markdown("---")
        st.subheader(f"📊 Database: {len(all_candidates)} candidates")
        
        # Show recent additions
        recent = sorted(all_candidates, key=lambda x: x.get('created_at', ''), reverse=True)[:5]
        st.write("**Recent additions:**")
        for candidate in recent:
            st.write(f"• {candidate.get('name', 'Unknown')} - Added: {candidate.get('created_at', 'Unknown')[:10]}")


def parse_and_add_to_database(uploaded_files, parser, db):
    """Parse resumes and add to database (optimized for bulk)"""
    total_files = len(uploaded_files)
    progress_bar = st.progress(0)
    status_text = st.empty()
    
    added_count = 0
    error_count = 0
    
    for i, uploaded_file in enumerate(uploaded_files):
        try:
            tmp_path = save_uploaded_file(uploaded_file)
            parsed_data = parser.parse_file(tmp_path)
            candidate_id = db.add_candidate(parsed_data)
            cleanup_file(tmp_path)
            added_count += 1
        except Exception as e:
            error_count += 1
            st.error(f"❌ Error: {uploaded_file.name} - {str(e)}")
        
        # Update progress
        progress = (i + 1) / total_files
        progress_bar.progress(progress)
        status_text.text(f"Processing {i+1}/{total_files}... ({added_count} added, {error_count} errors)")
    
    progress_bar.empty()
    status_text.empty()
    
    if added_count > 0:
        st.success(f"🎉 Successfully added {added_count} candidate(s) to database!")
        if error_count > 0:
            st.warning(f"⚠️ {error_count} file(s) had errors")
        st.info("💡 Go to 'Candidate Search' tab to search and filter candidates")
        
        # Show statistics if available
        if hasattr(db, 'get_statistics'):
            stats = db.get_statistics()
            st.json(stats)


def parse_resumes(uploaded_files, parser):
    """Parse uploaded resume files"""
    with st.spinner("Parsing resumes..."):
        candidates = []
        for uploaded_file in uploaded_files:
            try:
                tmp_path = save_uploaded_file(uploaded_file)
                parsed_data = parser.parse_file(tmp_path)
                candidates.append(parsed_data)
                cleanup_file(tmp_path)
                st.success(f"✅ Parsed: {uploaded_file.name}")
            except Exception as e:
                st.error(f"❌ Error parsing {uploaded_file.name}: {str(e)}")
        
        if candidates:
            st.session_state.candidates = candidates
            st.success(f"Successfully parsed {len(candidates)} resume(s)!")


def get_job_description_input() -> str:
    """Get job description from user input or file upload"""
    job_input_method = st.radio(
        "Input method:",
        ["Text Input", "File Upload"],
        horizontal=True
    )
    
    if job_input_method == "Text Input":
        return st.text_area(
            "Paste job description:",
            height=300,
            help="Paste the complete job description text here"
        )
    else:
        uploaded_job = st.file_uploader(
            "Upload job description file",
            type=['pdf', 'docx', 'txt'],
            help="Upload a job description file"
        )
        if uploaded_job:
            try:
                tmp_path = save_uploaded_file(uploaded_job)
                job_text = extract_text_from_file(tmp_path)
                cleanup_file(tmp_path)
                return job_text
            except Exception as e:
                st.error(f"Error reading file: {str(e)}")
        return ""


def parse_job_description(job_text: str, parser):
    """Parse job description text"""
    if not job_text.strip():
        st.warning("Please enter or upload a job description first.")
        return
    
    with st.spinner("Parsing job description..."):
        try:
            job_data = parser.parse_text(job_text)
            st.session_state.job_description = job_data
            st.success("✅ Job description parsed successfully!")
            
            with st.expander("View Parsed Job Data"):
                st.json(job_data)
        except Exception as e:
            st.error(f"❌ Error parsing job description: {str(e)}")

def rankings_tab(parsers: Dict):
    """Display candidate rankings"""
    st.header("Candidate Rankings")
    
    # Validation
    if not st.session_state.candidates:
        st.warning("⚠️ Please upload and parse resumes first (Upload & Parse tab).")
        return
    
    if not st.session_state.job_description:
        st.warning("⚠️ Please upload and parse a job description first (Upload & Parse tab).")
        return
    
    # Ranking mode selection
    ranking_mode = st.radio(
        "Ranking Mode:",
        ["🧠 Human-Like Analysis (Recommended)", "📊 Traditional Keyword-Based"],
        help="Human-like analysis goes beyond keywords to evaluate career trajectory, problem-solving, and potential"
    )
    
    ranking_engine = parsers['ranking_engine'] if ranking_mode.startswith("🧠") else parsers['traditional_ranking_engine']
    
    # Rank candidates
    if st.button("🔄 Rank Candidates", type="primary"):
        rank_candidates(ranking_engine, ranking_mode)
    
    # Display rankings
    if st.session_state.ranked_candidates:
        st.markdown("---")
        st.subheader("📊 Ranking Summary")
        display_ranking_summary(st.session_state.ranked_candidates)
        
        st.markdown("---")
        st.subheader("📋 Detailed Rankings")
        for i, item in enumerate(st.session_state.ranked_candidates):
            display_candidate_details(item, i + 1)


def rank_candidates(ranking_engine, mode: str = "Human-Like"):
    """Rank candidates based on job requirements"""
    analysis_type = "human-like holistic analysis" if "Human-Like" in mode else "traditional keyword matching"
    with st.spinner(f"Performing {analysis_type}..."):
        try:
            ranked = ranking_engine.rank_candidates(
                st.session_state.candidates,
                st.session_state.job_description
            )
            st.session_state.ranked_candidates = ranked
            st.success(f"✅ Ranked {len(ranked)} candidates using {mode}!")
        except Exception as e:
            st.error(f"❌ Error ranking candidates: {str(e)}")
            st.exception(e)

def reports_tab(parsers: Dict):
    """Generate and display explainable reports"""
    st.header("Explainable AI Reports")
    
    if not st.session_state.ranked_candidates:
        st.warning("⚠️ Please rank candidates first (Rankings tab).")
        return
    
    st.subheader("Generate Reports")
    
    if st.button("📝 Generate All Reports", type="primary"):
        generate_all_reports(parsers['report_generator'])
    
    # Display reports
    if st.session_state.reports:
        st.markdown("---")
        st.subheader("📄 Generated Reports")
        display_reports()


def generate_all_reports(report_generator):
    """Generate reports for all ranked candidates"""
    st.session_state.reports = {}
    progress_bar = st.progress(0)
    
    for i, item in enumerate(st.session_state.ranked_candidates):
        candidate = item['candidate']
        job = st.session_state.job_description
        score_data = item['score_breakdown']
        
        with st.spinner(f"Generating report for {candidate.get('name', 'Candidate')}..."):
            try:
                report = report_generator.generate_report(candidate, job, score_data)
                candidate_name = candidate.get('name', f'Candidate_{i}')
                st.session_state.reports[candidate_name] = report
            except Exception as e:
                st.error(f"Error generating report: {str(e)}")
        
        progress_bar.progress((i + 1) / len(st.session_state.ranked_candidates))
    
    st.success("✅ All reports generated!")


def display_reports():
    """Display generated reports with download option"""
    for i, item in enumerate(st.session_state.ranked_candidates):
        candidate = item['candidate']
        candidate_name = candidate.get('name', f'Candidate_{i}')
        
        if candidate_name in st.session_state.reports:
            with st.expander(f"Report: {candidate_name} (Rank {i+1}, Score: {item['score']:.1%})"):
                report = st.session_state.reports[candidate_name]
                st.markdown(report)
                
                st.download_button(
                    label="📥 Download Report",
                    data=report,
                    file_name=f"report_{candidate_name.replace(' ', '_')}.md",
                    mime="text/markdown"
                )

if __name__ == "__main__":
    main()


