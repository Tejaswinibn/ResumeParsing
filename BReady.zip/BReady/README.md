# AI Recruitment Assistant 🤖

An intelligent AI-powered recruitment assistant that parses resumes and job descriptions, analyzes candidate fit using semantic similarity, ranks candidates, and generates explainable evaluation reports.

## Features

- **📄 Resume Parsing**: Extract structured data from PDF, DOCX, and TXT resume files
- **💼 Job Description Parsing**: Parse and extract requirements from job descriptions
- **🔍 Semantic Analysis**: Use advanced NLP embeddings to analyze candidate-job fit beyond keyword matching
- **🧠 Skill Ontology**: Understand skill relationships and transferability (e.g., Python → Django, React → Vue)
- **⚡ FAISS Integration**: Efficient vector search for large-scale candidate matching
- **📊 Intelligent Ranking**: Rank candidates based on multiple weighted factors
- **📝 Explainable Reports**: Generate human-readable reports explaining candidate evaluations
- **🌐 Web Interface**: Easy-to-use Streamlit web application
- **🔧 Modular Architecture**: Easy to swap components and extend functionality

## Technology Stack

- **NLP**: spaCy, NLTK, Pyresparser
- **Semantic Analysis**: Sentence Transformers (Hugging Face)
- **Vector Search**: FAISS (CPU) with numpy fallback
- **Skill Ontology**: Custom knowledge graph for skill relationships
- **LLM**: OpenAI GPT API (optional, for enhanced reports)
- **UI**: Streamlit
- **File Processing**: pdfplumber, python-docx
- **Architecture**: Modular design with interface-based components

## Installation

### Prerequisites

- Python 3.8 or higher
- pip package manager

### Setup Steps

1. **Clone or download this repository**

2. **Create a virtual environment (recommended)**
   ```bash
   python -m venv venv
   
   # On Windows
   venv\Scripts\activate
   
   # On macOS/Linux
   source venv/bin/activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Download spaCy English model**
   ```bash
   python -m spacy download en_core_web_sm
   ```

5. **Set up OpenAI API (Optional)**
   - Get a free API key from [OpenAI Platform](https://platform.openai.com/api-keys)
   - Create a `.env` file in the project root:
     ```
     OPENAI_API_KEY=your_api_key_here
     OPENAI_MODEL=gpt-3.5-turbo
     ```
   - Note: The application works without OpenAI API, but reports will use templates instead of AI-generated content

## Usage

### Running the Application

1. **Start the Streamlit app**
   ```bash
   streamlit run app.py
   ```

2. **Open your browser**
   - The app will automatically open at `http://localhost:8501`
   - If not, navigate to the URL shown in the terminal

### Using the Application

1. **Upload & Parse Tab**
   - Upload one or more resume files (PDF, DOCX, or TXT)
   - Click "Parse Resumes" to extract candidate information
   - Input or upload a job description
   - Click "Parse Job Description" to extract requirements

2. **Rankings Tab**
   - Click "Rank Candidates" to analyze and rank all candidates
   - View the ranking summary table
   - Explore detailed breakdowns for each candidate

3. **Reports Tab**
   - Click "Generate All Reports" to create evaluation reports
   - View detailed reports for each candidate
   - Download reports as Markdown files

## Project Structure

```
BReady/
├── app.py                 # Streamlit web application
├── config.py              # Configuration settings
├── resume_parser.py       # Resume parsing module
├── job_parser.py          # Job description parsing module
├── semantic_analyzer.py   # Semantic similarity analysis
├── vector_store.py        # FAISS-based vector search
├── skill_ontology.py      # Skill relationship mapping
├── ranking_engine.py      # Candidate ranking algorithm
├── report_generator.py    # Explainable report generation
├── interfaces.py          # Component interfaces for modularity
├── utils.py               # Utility functions
├── requirements.txt       # Python dependencies
├── setup.py               # Setup script
├── README.md             # This file
├── QUICKSTART.md         # Quick start guide
├── ARCHITECTURE.md       # Architecture documentation
├── .env.example          # Environment variables template
├── .gitignore           # Git ignore rules
├── sample_data/          # Sample resumes and job descriptions
├── uploads/             # Uploaded files (created automatically)
└── outputs/             # Generated outputs (created automatically)
```

## How It Works

### 1. Resume Parsing
- Extracts candidate name, contact info, skills, experience, education, projects, and certifications
- Uses regex patterns and NLP techniques for structured extraction

### 2. Job Description Parsing
- Extracts job title, company, required/preferred skills, responsibilities, and requirements
- Identifies experience level and domain

### 3. Semantic Analysis
- Creates embeddings using sentence transformers
- Uses FAISS for efficient vector search (with numpy fallback)
- Computes semantic similarity between candidate skills and job requirements
- Leverages skill ontology for enhanced matching (understands skill relationships)
- Analyzes project and experience relevance

### 4. Ranking Algorithm
- Combines multiple factors with weighted scoring:
  - Skill similarity (35%)
  - Experience relevance (30%)
  - Project similarity (20%)
  - Education/certifications (10%)
  - Soft skills (5%)

### 5. Report Generation
- Uses OpenAI GPT API (if available) for natural language explanations
- Falls back to template-based reports if API not configured
- Explains strengths, gaps, and provides recommendations

## Configuration

Edit `config.py` to customize:
- Embedding model selection
- Ranking weights
- File upload settings
- Directory paths

## Sample Data

See the `sample_data/` directory for example resumes and job descriptions to test the system.

## Limitations & Future Improvements

- **Current Limitations**:
  - Resume parsing accuracy depends on resume format consistency
  - Semantic analysis uses general-purpose models (not domain-specific)
  - No database persistence (data stored in session state)

- **Future Enhancements**:
  - Support for more file formats
  - Integration with ATS systems
  - Custom skill ontology/knowledge graph
  - Batch processing capabilities
  - Export to CSV/Excel
  - Multi-language support

## Troubleshooting

### Common Issues

1. **spaCy model not found**
   ```bash
   python -m spacy download en_core_web_sm
   ```

2. **Import errors**
   - Ensure all dependencies are installed: `pip install -r requirements.txt`

3. **OpenAI API errors**
   - Check your API key in `.env` file
   - Verify you have API credits available
   - The app works without OpenAI (uses template reports)

4. **File parsing errors**
   - Ensure uploaded files are not corrupted
   - Check file format is supported (PDF, DOCX, TXT)

## Contributing

This is a prototype project. Feel free to:
- Report issues
- Suggest improvements
- Submit pull requests

## License

This project is open-source and available for educational and commercial use.

## Acknowledgments

- Built with free and open-source tools
- Uses Hugging Face Transformers and Sentence Transformers
- Powered by Streamlit for the web interface

---

**Note**: This is a prototype system. For production use, consider additional validation, error handling, and security measures.

