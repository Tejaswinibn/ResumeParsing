# Complete Setup Guide - Step by Step

## Step 1: Install Python

Python is not currently installed on your system. Follow these steps:

### Option A: Install from Microsoft Store (Easiest)
1. Open Microsoft Store
2. Search for "Python 3.11" or "Python 3.12"
3. Click "Install"
4. Wait for installation to complete

### Option B: Install from Python.org (Recommended)
1. Go to https://www.python.org/downloads/
2. Download Python 3.11 or 3.12 (latest stable version)
3. Run the installer
4. **IMPORTANT**: Check the box "Add Python to PATH" during installation
5. Click "Install Now"
6. Wait for installation to complete

### Verify Python Installation
After installation, open a new PowerShell/Command Prompt and run:
```powershell
python --version
```
You should see something like: `Python 3.11.x` or `Python 3.12.x`

---

## Step 2: Navigate to Project Directory

Open PowerShell or Command Prompt and run:
```powershell
cd C:\Users\tej04\Desktop\BReady
```

---

## Step 3: Install Dependencies

Run this command to install all required packages:
```powershell
pip install -r requirements.txt
```

This will install:
- streamlit (web UI)
- spacy (NLP)
- sentence-transformers (embeddings)
- faiss-cpu (vector search)
- pdfplumber, python-docx (file processing)
- And all other dependencies

**Note**: This may take 5-10 minutes depending on your internet speed.

---

## Step 4: Download spaCy English Model

After dependencies are installed, run:
```powershell
python -m spacy download en_core_web_sm
```

This downloads the English language model needed for parsing.

---

## Step 5: (Optional) Set Up OpenAI API

If you want AI-generated reports (optional - app works without it):

1. Get a free API key from: https://platform.openai.com/api-keys
2. Create a file named `.env` in the project folder
3. Add this line to `.env`:
   ```
   OPENAI_API_KEY=your_api_key_here
   OPENAI_MODEL=gpt-3.5-turbo
   ```

**Note**: The app works perfectly without OpenAI - it will use template-based reports instead.

---

## Step 6: Run the Application

Once everything is installed, run:
```powershell
streamlit run app.py
```

The app will:
1. Start a local server
2. Automatically open in your browser at `http://localhost:8501`
3. If it doesn't open automatically, go to that URL manually

---

## Troubleshooting

### "python is not recognized"
- Python is not installed or not in PATH
- Reinstall Python and make sure to check "Add Python to PATH"
- Or use `py` instead of `python` (Windows Python Launcher)

### "pip is not recognized"
- Python might not be installed correctly
- Try: `python -m pip install -r requirements.txt`
- Or: `py -m pip install -r requirements.txt`

### "Module not found" errors
- Make sure you ran `pip install -r requirements.txt`
- Try: `pip install --upgrade pip` first
- Then: `pip install -r requirements.txt` again

### "spaCy model not found"
- Run: `python -m spacy download en_core_web_sm`
- Or: `py -m spacy download en_core_web_sm`

### Streamlit won't start
- Make sure streamlit is installed: `pip install streamlit`
- Try: `python -m streamlit run app.py`
- Check if port 8501 is already in use

---

## Quick Command Summary

```powershell
# 1. Navigate to project
cd C:\Users\tej04\Desktop\BReady

# 2. Install dependencies
pip install -r requirements.txt

# 3. Download spaCy model
python -m spacy download en_core_web_sm

# 4. Run the app
streamlit run app.py
```

---

## Need Help?

If you encounter any issues:
1. Make sure Python is installed and in PATH
2. Make sure you're in the correct directory
3. Try running commands with `python -m` prefix
4. Check that all dependencies installed successfully

Good luck! 🚀


