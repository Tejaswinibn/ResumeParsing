# Architecture Documentation

## Overview

The AI Recruitment Assistant is built with a **modular architecture** that allows easy component swapping, testing, and extension. Each component follows clear interfaces and can be replaced without affecting other parts of the system.

## Architecture Principles

1. **Modularity**: Each component is independent and can be swapped
2. **Interface-based Design**: Components implement interfaces for easy replacement
3. **Separation of Concerns**: Clear boundaries between parsing, analysis, ranking, and reporting
4. **Extensibility**: Easy to add new features or replace implementations
5. **Configuration-driven**: Settings centralized in `config.py`

## Component Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     Streamlit UI (app.py)                    │
└───────────────────────┬─────────────────────────────────────┘
                        │
        ┌───────────────┼───────────────┐
        │               │               │
┌───────▼──────┐ ┌──────▼──────┐ ┌─────▼──────┐
│   Parsers    │ │   Ranking   │ │  Reports   │
│              │ │   Engine    │ │ Generator  │
│ ResumeParser │ │             │ │            │
│  JobParser   │ │             │ │            │
└──────┬───────┘ └──────┬───────┘ └────────────┘
       │               │
       │      ┌────────▼────────┐
       │      │ Semantic Analyzer│
       │      │                  │
       │      │  ┌─────────────┐│
       │      │  │Vector Store ││
       │      │  │  (FAISS)    ││
       │      │  └─────────────┘│
       │      │  ┌─────────────┐│
       │      │  │   Skill     ││
       │      │  │  Ontology   ││
       │      │  └─────────────┘│
       │      └─────────────────┘
       │
┌──────▼──────────────────────────┐
│      Configuration (config.py)   │
└──────────────────────────────────┘
```

## Core Components

### 1. Parsers (`resume_parser.py`, `job_parser.py`)

**Purpose**: Extract structured data from unstructured text

**Features**:
- Support multiple file formats (PDF, DOCX, TXT)
- Extract entities: skills, experience, education, projects
- Use spaCy for NLP processing
- Fallback to regex-based parsing if spaCy unavailable

**Interface**: Implements parsing logic (can be extended with `IParser`)

**Swappable**: Yes - can replace with different parsing libraries

### 2. Semantic Analyzer (`semantic_analyzer.py`)

**Purpose**: Compute semantic similarity between candidates and jobs

**Features**:
- Uses sentence transformers for embeddings
- Integrates with FAISS for efficient vector search
- Uses skill ontology for enhanced matching
- Computes similarity scores for skills, projects, experience

**Dependencies**:
- `vector_store.py` - FAISS-based vector search
- `skill_ontology.py` - Skill relationship mapping

**Swappable**: Yes - can swap embedding models or vector stores

### 3. Vector Store (`vector_store.py`)

**Purpose**: Efficient similarity search using FAISS

**Features**:
- FAISS-based indexing for fast search
- Falls back to numpy if FAISS unavailable
- Supports batch operations
- Metadata storage for each vector

**Swappable**: Yes - can replace with other vector databases (Pinecone, Weaviate, etc.)

### 4. Skill Ontology (`skill_ontology.py`)

**Purpose**: Understand skill relationships and transferability

**Features**:
- Maps related skills (e.g., Python → Django, Flask)
- Identifies skill groups (frontend, backend, databases)
- Handles skill aliases (Node.js, NodeJS, node)
- Enhances matching beyond exact keywords

**Swappable**: Yes - can replace with external knowledge graphs

### 5. Ranking Engine (`ranking_engine.py`)

**Purpose**: Rank candidates based on multiple weighted factors

**Features**:
- Weighted scoring system
- Configurable weights via `config.py`
- Combines multiple signals:
  - Skill similarity (35%)
  - Experience relevance (30%)
  - Project similarity (20%)
  - Education/certifications (10%)
  - Soft skills (5%)

**Interface**: Implements `IRankingStrategy`

**Swappable**: Yes - can implement different ranking algorithms

### 6. Report Generator (`report_generator.py`)

**Purpose**: Generate explainable evaluation reports

**Features**:
- OpenAI GPT API integration (optional)
- Template-based fallback
- Explains strengths, gaps, recommendations

**Interface**: Can implement `IReportGenerator`

**Swappable**: Yes - can use different LLMs or templates

### 7. Interfaces (`interfaces.py`)

**Purpose**: Define contracts for components

**Interfaces**:
- `IParser` - For parsers
- `IEmbeddingModel` - For embedding models
- `IRankingStrategy` - For ranking algorithms
- `IReportGenerator` - For report generators
- `IVectorStore` - For vector stores

**Usage**: Allows type checking and easy component swapping

### 8. Utilities (`utils.py`)

**Purpose**: Shared utility functions

**Features**:
- File validation
- Logging setup
- Score formatting
- Duration parsing
- Key phrase extraction

## Data Flow

1. **Upload & Parse**
   - User uploads resumes/job description
   - Parsers extract structured data
   - Data stored in session state

2. **Semantic Analysis**
   - Semantic analyzer creates embeddings
   - Compares candidate skills vs job requirements
   - Uses skill ontology for enhanced matching
   - Vector store enables efficient search

3. **Ranking**
   - Ranking engine calculates scores
   - Combines multiple factors with weights
   - Produces ranked candidate list

4. **Report Generation**
   - Report generator creates explanations
   - Uses LLM (if available) or templates
   - Explains fit, gaps, recommendations

## Configuration

All settings in `config.py`:
- Model selection
- Ranking weights
- File upload limits
- API keys
- Directory paths

## Extensibility Points

### Adding New Parsers
1. Implement `IParser` interface
2. Add to parser factory in `app.py`
3. Update file handling logic

### Swapping Embedding Models
1. Change `EMBEDDING_MODEL` in `config.py`
2. Or pass custom model to `SemanticAnalyzer`

### Custom Ranking Algorithm
1. Implement `IRankingStrategy`
2. Replace `RankingEngine` in `app.py`

### Different Vector Store
1. Implement `IVectorStore`
2. Update `SemanticAnalyzer` to use new store

### Alternative LLM
1. Modify `ReportGenerator`
2. Add new LLM client
3. Update prompt templates

## Performance Considerations

- **Caching**: Streamlit caches parsers and models
- **FAISS**: Fast vector search for large candidate pools
- **Batch Processing**: Supports batch operations where possible
- **Lazy Loading**: Models loaded on first use

## Testing Strategy

Each component can be tested independently:
- Unit tests for parsers
- Integration tests for semantic analysis
- End-to-end tests for full workflow

## Future Enhancements

1. **Database Integration**: Store candidates and jobs
2. **API Layer**: REST API for programmatic access
3. **Batch Processing**: Process multiple jobs at once
4. **Advanced Analytics**: Dashboard with statistics
5. **Multi-language Support**: Parse resumes in different languages
6. **Knowledge Graph**: External skill ontology integration

## Dependencies

- **Core**: Python 3.8+
- **NLP**: spaCy, NLTK
- **Embeddings**: sentence-transformers
- **Vector Search**: FAISS (optional, falls back to numpy)
- **LLM**: OpenAI API (optional)
- **UI**: Streamlit
- **File Processing**: pdfplumber, python-docx

## Modularity Checklist

✅ Components are independent
✅ Clear interfaces defined
✅ Configuration centralized
✅ Easy to swap implementations
✅ Fallback mechanisms in place
✅ Error handling throughout
✅ Logging support
✅ Documentation included

---

This architecture ensures the system is maintainable, testable, and extensible while remaining simple enough for a prototype.


