"""
Configuration file for AI Recruitment Assistant
"""
import os
from dotenv import load_dotenv

load_dotenv()

# OpenAI Configuration
# Note: These will be updated by app.py if Streamlit secrets are available
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-3.5-turbo")

# Model Configuration
EMBEDDING_MODEL = "all-MiniLM-L6-v2"  # Lightweight sentence transformer model
SPACY_MODEL = "en_core_web_sm"  # Small English model for spaCy

# File Upload Settings
ALLOWED_EXTENSIONS = {".pdf", ".docx", ".txt"}
MAX_FILE_SIZE_MB = 10

# Ranking Weights
RANKING_WEIGHTS = {
    "skill_similarity": 0.35,
    "experience_relevance": 0.30,
    "project_similarity": 0.20,
    "education_certifications": 0.10,
    "soft_skills": 0.05
}

# Directories
UPLOAD_DIR = "uploads"
OUTPUT_DIR = "outputs"

# Create directories if they don't exist
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)


