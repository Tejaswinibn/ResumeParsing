# Deployment Guide for Streamlit Community Cloud

Your code is already on GitHub at: **https://github.com/Tejaswinibn/ResumeParsing**

## Quick Deployment Steps

### Option 1: Deploy Directly from GitHub (Recommended)

1. **Go to Streamlit Community Cloud**
   - Visit: https://share.streamlit.io/
   - Sign in with your GitHub account

2. **Deploy Your App**
   - Click "New app"
   - Select your repository: `Tejaswinibn/ResumeParsing`
   - Select branch: `main`
   - Main file path: `app.py`
   - Click "Deploy"

3. **Configure Environment Variables (Optional)**
   - If you want to use OpenAI API, add these secrets:
     - `OPENAI_API_KEY`: Your OpenAI API key
     - `OPENAI_MODEL`: `gpt-3.5-turbo` (optional)

### Option 2: Update Local Code and Push to GitHub

If you have local changes that aren't on GitHub:

1. **Install Git** (if not installed)
   - Download from: https://git-scm.com/download/win
   - Or use GitHub Desktop: https://desktop.github.com/

2. **Connect Local Repository to GitHub**
   ```bash
   git init
   git remote add origin https://github.com/Tejaswinibn/ResumeParsing.git
   git add .
   git commit -m "Update project files"
   git push -u origin main
   ```

3. **Then deploy from Streamlit Community Cloud** (follow Option 1)

## Important Files for Deployment

Make sure these files are in your GitHub repository:

- ✅ `app.py` - Main Streamlit application
- ✅ `requirements.txt` - Python dependencies
- ✅ All Python modules (`.py` files)
- ✅ `README.md` - Documentation

## Streamlit Community Cloud Requirements

1. **Repository must be public** (or you need Streamlit Pro for private repos)
2. **Main file**: `app.py` (or specify in deployment settings)
3. **Python version**: Will auto-detect from `requirements.txt` or use Python 3.11

## Troubleshooting Deployment

### Issue: "Unable to deploy - not connected to GitHub"
- **Solution**: Your code is already on GitHub! Just use the GitHub repository URL when deploying on Streamlit Community Cloud.

### Issue: "Module not found" errors
- **Solution**: Make sure all dependencies are in `requirements.txt`
- Check that all `.py` files are committed to GitHub

### Issue: "spaCy model not found"
- **Solution**: Add this to your `requirements.txt` or create a `packages.txt`:
  ```
  https://github.com/explosion/spacy-models/releases/download/en_core_web_sm-3.7.1/en_core_web_sm-3.7.1-py3-none-any.whl
  ```
- Or add a `setup.sh` script to download the model

### Issue: "OpenAI API errors"
- **Solution**: Add your API key as a secret in Streamlit Community Cloud settings
- Go to: App Settings → Secrets → Add secret

## Creating setup.sh for spaCy Model

Create a file `setup.sh` in your repository root:

```bash
#!/bin/bash
python -m spacy download en_core_web_sm
```

Then in Streamlit Community Cloud, it will run automatically.

## Alternative: Add spaCy Model to requirements.txt

You can also add the spaCy model directly to requirements.txt:

```
# Add this line to requirements.txt
https://github.com/explosion/spacy-models/releases/download/en_core_web_sm-3.7.1/en_core_web_sm-3.7.1-py3-none-any.whl
```

## Your Repository Status

✅ **Repository exists**: https://github.com/Tejaswinibn/ResumeParsing
✅ **All files are present** on GitHub
✅ **Ready for deployment**

## Next Steps

1. Go to https://share.streamlit.io/
2. Sign in with GitHub
3. Click "New app"
4. Select: `Tejaswinibn/ResumeParsing`
5. Main file: `app.py`
6. Click "Deploy"

Your app will be live at: `https://your-app-name.streamlit.app`

---

**Note**: If you make changes locally, you'll need to push them to GitHub for Streamlit to pick them up. Streamlit Community Cloud automatically redeploys when you push to the main branch.

