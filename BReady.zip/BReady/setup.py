"""
Setup script for AI Recruitment Assistant
Helps with initial setup and dependency installation
"""
import subprocess
import sys
import os

def run_command(command, description):
    """Run a shell command and handle errors"""
    print(f"\n{'='*50}")
    print(f"Running: {description}")
    print(f"Command: {command}")
    print(f"{'='*50}\n")
    
    try:
        result = subprocess.run(command, shell=True, check=True, capture_output=True, text=True)
        print(result.stdout)
        return True
    except subprocess.CalledProcessError as e:
        print(f"Error: {e.stderr}")
        return False

def main():
    """Main setup function"""
    print("="*60)
    print("AI Recruitment Assistant - Setup Script")
    print("="*60)
    
    # Check Python version
    python_version = sys.version_info
    if python_version.major < 3 or (python_version.major == 3 and python_version.minor < 8):
        print("ERROR: Python 3.8 or higher is required!")
        sys.exit(1)
    
    print(f"✓ Python {python_version.major}.{python_version.minor}.{python_version.micro} detected")
    
    # Install dependencies
    print("\n1. Installing Python dependencies...")
    if not run_command(f"{sys.executable} -m pip install --upgrade pip", "Upgrading pip"):
        print("Warning: Failed to upgrade pip, continuing anyway...")
    
    if not run_command(f"{sys.executable} -m pip install -r requirements.txt", "Installing requirements"):
        print("ERROR: Failed to install dependencies!")
        sys.exit(1)
    
    # Download spaCy model
    print("\n2. Downloading spaCy English model...")
    if not run_command(f"{sys.executable} -m spacy download en_core_web_sm", "Downloading spaCy model"):
        print("Warning: Failed to download spaCy model. You may need to run this manually:")
        print("  python -m spacy download en_core_web_sm")
    
    # Create .env file if it doesn't exist
    print("\n3. Setting up environment file...")
    if not os.path.exists(".env"):
        if os.path.exists(".env.example"):
            import shutil
            shutil.copy(".env.example", ".env")
            print("✓ Created .env file from .env.example")
            print("  Please edit .env and add your OpenAI API key (optional)")
        else:
            print("⚠ .env.example not found, skipping...")
    else:
        print("✓ .env file already exists")
    
    # Create necessary directories
    print("\n4. Creating directories...")
    directories = ["uploads", "outputs"]
    for directory in directories:
        os.makedirs(directory, exist_ok=True)
        print(f"✓ Created/verified {directory}/ directory")
    
    print("\n" + "="*60)
    print("Setup completed successfully!")
    print("="*60)
    print("\nNext steps:")
    print("1. (Optional) Edit .env file and add your OpenAI API key")
    print("2. Run the application: streamlit run app.py")
    print("\nFor more information, see README.md")

if __name__ == "__main__":
    main()


