#!/bin/bash
# Setup script for Streamlit Community Cloud deployment
# Downloads spaCy English model

python -m spacy download en_core_web_sm

